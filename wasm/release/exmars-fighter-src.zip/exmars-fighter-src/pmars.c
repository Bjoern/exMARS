/* exMARS  -- Exhaust Memory Array Redcode Simulator
 * Copyright (C) 1993-2003 Albert Ma, Na'ndor Sieben, Stefan Strack,
 * Mintardjo Wangsawidjaja and Martin Ankerl
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#define EXMARS_VERSION "0.01-ai.2"

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
/* Add this to the top of pmars.c */

#include <string.h>

/* ==========================================================
 * MSVC (Windows) Compatibility Fix
 * ==========================================================
 */
#ifdef _MSC_VER
    /* MSVC doesn't have strtok_r, it has strtok_s */
    /* This defines strtok_r as a macro that calls strtok_s */
    #define strtok_r(str, delim, saveptr) strtok_s(str, delim, saveptr)

    /* MSVC uses _strdup for strdup */
    #define strdup _strdup
#endif
/* ==========================================================
 */
#include <stdio.h>
#include "exhaust.h"
#include "sim.h"
#include "insn_help.h"
#include "insn.h"
#include "match.h"

#define concat(a,b) (strlen(a)+strlen(b)<MAXALLCHAR?pstrcat((a),(b)):NULL)
#ifndef min
#define min(x,y) ((x)<(y) ? (x) : (y))
#endif


/**************************** config **********************************/
#define NEW_OPCODES
#define NEW_MODES
#define PSPACE
#define SHARED_PSPACE

#define NONE      0
#define ADDRTOKEN 1
#define FSEPTOKEN 2
#define COMMTOKEN 3
#define MODFTOKEN 4
#define EXPRTOKEN 5
#define WSPCTOKEN 6
#define CHARTOKEN 7
#define NUMBTOKEN 8
#define APNDTOKEN 9
#define MISCTOKEN 10                /* unrecognized token */

#define sep_sym ','
#define com_sym ';'
#define mod_sym '.'
#define cat_sym '&'
#define cln_sym ':'

#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

/* *********************************************************************
   System dependent definitions or declarations
   ********************************************************************* */



/* ************************************************************************
   pmars global structures and definitions
   ************************************************************************ */

#define PMARSVER  92
#define PMARSDATE "25/12/00"

/* return code:
   0: success
   Negative number: System error such as insufficient space, etc
   Positive number: User error such as number too big, file not found, etc */
#define GRAPHERR  -4                /* graphic error */
#define NOT386    -3                /* trying to execute 386 code on lesser
                                     * machine */
#define MEMERR    -2                /* insufficient memory, cannot free, etc. */
#define SERIOUS   -1                /* program logic error */
#define FNOFOUND   1                /* File not found */
#define CLP_NOGOOD 2                /* command line argument error */
#define PARSEERR   3                /* File doesn't assemble correctly */
#define USERABORT  4                /* user stopped program from cdb, etc. */

/* these are used as return codes of internal functions */

/* used by eval.c */
#define PMARS_OVERFLOW  1
#define OK_EXPR   0
#define BAD_EXPR -1
#define DIV_ZERO -2

/* used by cdb.c */
#define NOBREAK 0
#define BREAK   1
#define STEP    2

#define SKIP    1                /* cmdMod settings for cdb: skip next command */
#define RESET   2                /* clear command queue */

#define UNSHARED -1                /* P-space is private */
#define PIN_APPEARED -2


/* used by many */
#define STDOUT stdout

#define MAXCORESIZE   ((INT_MAX>>1)+1)
#define MAXTASKNUM    INT_MAX
#define MAXROUND      INT_MAX
#define MAXCYCLE      LONG_MAX
#define MAXINSTR      ((INT_MAX>>1)+1)

const char    addr_sym[] = {'#', '$', '@', '<', '>', '*', '{', '}', '\0'};
const char    expr_sym[] =
{'(', ')', '/', '+', '-', '%', '!', '=', '\0'};

const char   *opname[] =
{"MOV", "ADD", "SUB", "MUL", "DIV", "MOD", "JMZ",        /* op */
 "JMN", "DJN", "CMP", "SLT", "SPL", "DAT", "JMP",        /* op */
 "SEQ", "SNE", "NOP",                /* ext op */
 "LDP", "STP",
 "ORG", "END",                        /* pseudo-opcodes */
#ifdef SHARED_PSPACE
 "PIN", ""};
#else
""};
#endif

const char   *modname[] = {"A", "B", "AB", "BA", "F", "X", "I", ""};
const char   *swname[] = {"ASSERT", ""};

/* ***********************************************************************
   function prototypes
   *********************************************************************** */
int parse_param(int argc, char *argv[]);
int eval_expr(mars_t* mars, char *expr, long *result);
int assemble(char *fName, int aWarrior);
void disasm(mars_t* mars, mem_struct * cells, ADDR_T n, ADDR_T offset);
void simulator1(void);
char *locview(ADDR_T loc, char *outp);
int cdb(char *msg);
int score(int warnum);
int deaths(int warnum);
void results(FILE * outp);
void Exit(int code);
void reset_regs(mars_t* mars);

char *cellview(mars_t* mars, mem_struct * cell, char *outp);

char* pstrdup(char *);
char* pstrcat(char *, char *);
const char* pstrchr(const char *, int);
uChar ch_in_set(char c, const char* s);
uChar skip_space(char *, uChar);
uChar str_in_set(char *, const char *s[]);
int get_token(char * , uChar *, char *);
void to_upper(char *);


/* ****************** required local prototypes ********************* */

static void textout(char *);
static void errprn(mars_t* mars, errType code, line_st* aline, const char* arg);

/* ***************** conforming local prototypes ******************** */
static int trav2(mars_t* mars, char* buffer, char* dest, int wdecl);
static int normalize(mars_t* mars, long);
static int blkfor(mars_t* mars, char *, char *);
static int equtbl(mars_t* mars, char *);
static int equsub(mars_t* mars, char *, char *, int, ref_st *);
static ref_st *lookup(mars_t* mars, char *);
static grp_st *addsym(mars_t* mars, char *, grp_st *);
static src_st *addlinesrc(mars_t* mars, char *, uShrt);
static void newtbl(mars_t* mars);
static void addpredef(mars_t* mars, char *, U32_T);
static void addpredefs(mars_t* mars);
static void addline(mars_t* mars, char*, src_st*, uShrt);
static void disposeline(line_st *), disposegrp(grp_st *);
static void disposetbl(ref_st *, ref_st *);
static void cleanmem(mars_t* mars);
static void nocmnt(char *);
static void automaton(mars_t* mars, char *, stateCol, mem_struct *);
static void dfashell(mars_t* mars, char *, mem_struct *);
static void expand(mars_t* mars, uShrt);

int denormalize(mars_t* mars, int x);
void disposesrc(src_st* r);

int globalswitch_warrior(mars_t* mars, warrior_struct* w, char* str, uShrt idx, uShrt loc, uShrt lspnt);
void encode_warrior(mars_t* mars, warrior_struct* w, uShrt sspnt);
void panic(const char *msg);
int assemble_warrior(mars_t* mars, char* fName, warrior_struct* w);
void check_sanity(mars_t* mars);
void readargs(int argc, char** argv, mars_t* mars);
void usage(void);
void output_results(mars_t* mars);
mars_t* init(int argc, char** argv);
void pmars2exhaust(mars_t* mars, warrior_struct** warriors, int wCount);



/* *************************** external strings ************************** */

char   *outOfMemory = "Out of memory\n";
char   *warriorTerminated = "Warrior %d: %s terminated\n";
char   *fatalErrorInSimulator = "Fatal error in simulator. Please report this error.\n";
char   *warriorTerminatedEndOfRound = "Warrior %d: %s terminated - End of round %d\n";
char   *endOfRound = "End of round %d\n";

char   *nameByAuthorScores = "%s by %s scores %d\n";
char   *resultsAre = "  Results:";
char   *resultsWLT = "Results: %d %d %d\n";

/* pmars.c */

char   *info01 = "Program \"%s\" (length %d) by \"%s\"\n\n";

/* asm.c */
char   *logicErr = "Error in %s. Line: %d\n";
char   *labelRefMsg = "Label references:\n";
char   *groupLabel = "Group label(s):\n";
char   *textMsg = "(TEXT):";
char   *stackMsg = "(STACK):";
char   *labelMsg = "(LABEL):";
char   *endOfChart = "***END*OF*CHART***\n\n";
char   *afterPass = "After pass %d\n";
char   *instrMsg = "Instruction (physical line, instr):\n\n";
char   *endOfPass = "\n***END*OF*PASS***\n\n";
char   *unknown = "Unknown";
char   *anonymous = "Anonymous";
char   *illegalAppendErr = "Attempting to append a string to an undefined label";
char   *bufferOverflowErr = "Buffer overflow. Substitution is too complex";
char   *illegalConcatErr = "Illegal use of string concatenation '%s'";
char   *tooManyLabelsErr = "Too many labels for a declaration (last: '%s')";
char   *unopenedFORErr = "Unopened FOR";
char   *unclosedROFErr = "Unclosed ROF";
char   *bad88FormatErr = "Bad '88 format at token '%s'";
char   *badOffsetErr = "Execution starts from outside of the program";
char   *noInstErr = "No instructions";
char   *spaceRedErr = "Putting space between ';' and 'redcode' is useless";
char   *tokenErr = "Unrecognized or improper placement of token: '%s'";
char   *terminatedRedErr = "Source code terminated by ';redcode'";
char   *undefinedSymErr = "Undefined label or symbol: '%s'";
char   *expectNumberErr = "Expecting a number";
char   *syntaxErr = "Syntax error";
char   *discardLabelErr = "Discarding these labels: '%s'";
char   *tooManyInstrErr = "Too many instructions (about %s more)";
char   *missingErr = "Missing '%s'";
char   *recursiveErr = "Recursive reference of label '%s'";
char   *badExprErr = "Bad expression";
char   *divZeroErr = "Division by zero";
char   *overflowErr = "Arithmetic overflow detected";
char   *missingAssertErr = "Missing ';assert'. Warrior may not work with the current setting";
char   *concatErr = "Unable to derefer and concatenate symbol '%s'";
char   *ignoreENDErr = "Both opcodes ORG and END are used. Ignoring END";
char   *invalidAssertErr = "Invalid ';assert' parameter";
char   *tooMuchStuffErr = "Lines generated by the source exceed the limit %d\n\tIgnoring code generation";
char   *extraTokenErr = "Ignored, extra tokens in line '%s'";
char   *improperPlaceErr = "Improper placement of '%s'";
char   *invalid88Err = "Invalid '88 format. Proper format: '%s'";
char   *incompleteOpErr = "Incomplete operand at instruction '%s'";
char   *redefinitionErr = "Ignored, redefinition of label '%s'";
char   *undefinedLabelErr = "Undefined label '%s'";
char   *assertionFailErr = "Assertion in this line fails";
char   *tooManyMsgErr = "\nToo many errors or warnings.\nAssembly aborted.\n";
char   *fileOpenErr = "Unable to open file '%s'";
char   *fileReadErr = "Unable to read file '%s'";
char   *notEnoughMemErr = "MALLOC() fails\nProgram aborted\n";
char   *warning = "Warning";
char   *error = "Error";
char   *inLine = " in line %d: '%s'\n";
char   *opcodeMsg = "opcode";
char   *modifierMsg = "modifier";
char   *aTerm = "A-term";
char   *bTerm = "B-term";
char   *currentAssertMsg = "Current parameter for ';assert': %s\n";
char   *currentFORMsg = "Current parameter for FOR: %s\n";
char   *CURLINEErr = "CURLINE is a reserved keyword";
char   *paramCheckMsg = "Parameter checking:\n";
char   *errNumMsg = "Number of errors: %d\n";
char   *warNumMsg = "Number of warnings: %d\n";
char   *duplicateMsg = "Duplicate errors/warnings found in line %d (%d)\n";

/* Strings from clparse.c: */
char   *credits_screen1 = "pMARS v%d.%d.%d, %s, corewar simulator with ICWS'94 extensions\n";
char   *credits_screen2 = "Copyright (C) 1993-95 Albert Ma, Na'ndor Sieben, Stefan Strack and Mintardjo Wangsaw\n";
char   *credits_screen3 = "SERVER version without debugger\n";
char   *usage_screen = "Usage:\n   pmars [options] file1 [files ..]\n   The special file - stands for standard input\n\n";
char   *optionsAre = "Options:\n";
char   *readingStdin = "[Reading from standard input until EOF or \"$\"]\n";
char   *readOptionsFromFile = "  -@ $ Read options from file $\n";
char   *standardInput = "standard input";
char   *errorIsLocatedIn = "The error is located in \"%s\"\n";
char   *unknownOption = "\nUnknown option \"%s\"\n";
char   *badArgumentForSwitch = "\nBad argument for \"-%c\" switch\n";
char   *optionMustBeInTheRange = "\nOption \"-%c\" value must be in the range ";
char   *tooManyParameters = "\nToo many parameters \"%s\"\n";
char   *cannotOpenParameterFile = "\nCannot open parameter file\n";
char   *optRounds = "Rounds to play [1]";
char   *optEnterDebugger = "Enter debugger";
char   *optDisabledInServerVersion = "(disabled in SERVER version)";
char   *optCoreSize = "Size of core [8000]";
char   *optBrief = "Brief mode (no source listings)";
char   *optCycles = "Cycles until tie [80000]";
char   *optVerboseAssembly = "Verbose assembly";
char   *optProcesses = "Max. processes [8000]";
char   *optKotH = "Output in KotH format";
char   *optLength = "Max. warrior length [100]";
char   *opt88 = "Enforce ICWS'88 rules";
char   *optDistance = "Min. warriors distance";
char   *optFixedSeries = "Fixed position series";
char   *optFixedPosition = "Fixed position of warrior #2";
char   *optSort = "Sort result output by score";
char   *optScoreFormula = "Score formula $ [(W*W-1)/S]";
char   *optPSpaceSize = "Size of P-space [1/16th core]";
char   *optPermutate = "Permutate starting positions";
char   *noWarriorFile = "\nNo warrior file specified\n";
char   *fFExclusive = "\nOnly one of -f and -F can be given\n";
char   *coreSizeTooSmall = "\nCore size is too small\n";
char   *dLessThanl = "\nWarrior distance cannot be smaller than warrior length\n";
char   *FLessThand = "\nPosition of warrior #2 cannot be smaller than warrior distance\n";
char   *badScoreFormula = "\nBad score formula\n";
char   *pSpaceTooBig = "\nP-space is bigger than core\n";
char   *permutateMultiWarrior = "\nPermutation cannot be used in multiwarrior battles\n";



/* ********************** macros + type definitions ********************** */

/*
 * Fatal assembler errors (internal logic error, out of memory, too many errors)
 * used to call exit(), which killed any program embedding the assembler. Now
 * they jump back to assemble_warrior()/assemble_warrior_from_string(), which
 * free the parser's memory and return the code. Without a jump point (code
 * calling the parser directly) they still exit as before.
 */
#define PARSE_ABORT_LOGIC  SERIOUS
#define PARSE_ABORT_MEMORY MEMERR
#define PARSE_ABORT_ERRORS PARSEERR

static void parse_abort(mars_t *mars, int code)
{
    if (mars->parseAbort) {
        mars->errorcode = code;
        longjmp(*mars->parseAbort, 1);
    }
    exit(code == PARSE_ABORT_MEMORY ? MEMERR : PARSEERR);    /* the old exit codes */
}

#define LOGICERROR do { fprintf(STDOUT, logicErr, __FILE__, __LINE__);  \
        snprintf(mars->errmsg, sizeof mars->errmsg, "internal assembler error (%s line %d)", __FILE__, __LINE__); \
        parse_abort(mars, PARSE_ABORT_LOGIC); } while(0)

#define MEMORYERROR errprn(mars, MLCERR, (line_st *) NULL, "")


#ifdef SHARED_PSPACE
#define PSEOPNUM 4                /* also PIN */
#else
#define PSEOPNUM 3
#endif                                /* SHARED_PSPACE */

#define OPNUM (sizeof(opname)/sizeof(opname[0])) - PSEOPNUM

#define ORGOP (OPNUM + 0)
#define ENDOP (OPNUM + 1)
#define PINOP (OPNUM + 2)
#define EQUOP (OPNUM + 3)        /* this has to be the last */

#define MODNUM ((sizeof(modname)/sizeof(modname[0])) - 1)
#define SWNUM  ((sizeof(swname)/sizeof(swname[0])) - 1)

#define ERRMAX   9                /* max error */
#define GRPMAX   7                /* max group */
#define LEXCMAX  50                /* max number of excess lines */

#define BIGNUM 20                /* largest number taken */

/* two-char operators, distinct from single-character operators */
enum {
    EQUAL = 256, NEQU, GTE, LTE, AND, OR
};


/* converts pmars order to exhaust order */

enum ex_op p2eOp[] = {
    EX_MOV, EX_ADD, EX_SUB, EX_MUL, EX_DIV, EX_MODM, EX_JMZ,
    EX_JMN, EX_DJN, EX_SEQ, EX_SLT, EX_SPL, EX_DAT, EX_JMP, /* CMP = SEQ */
    EX_SEQ, EX_SNE, EX_NOP, EX_LDP, EX_STP
};

enum ex_modifier p2eModifier[] = {
    EX_mA,                                /* .A */
    EX_mB,                                /* .B */
    EX_mAB,                                /* .AB */
    EX_mBA,                                /* .BA */
    EX_mF,                                /* .F */
    EX_mX,                                /* .X */
    EX_mI                                /* .I */   
};

enum ex_addr_mode p2eAddr[] = {
/* addr_sym[] = {'#', '$', '@', '<', '>', '*', '{', '}', '\0'}; */
    EX_IMMEDIATE, /* # */
    EX_DIRECT,  /* $ */
    EX_BINDIRECT,   /* @ */
    EX_BPREDEC, /* < */
    EX_BPOSTINC,    /* > */
    EX_AINDIRECT,   /* * */
    EX_APREDEC, /* { */
    EX_APOSTINC /* } */   /* 8 */
};

    

/*--------------------*/
/* Bounded expression evaluator, ported from pMARS 0.9.6 (eval.c). The
 * inherited 0.9.2 evaluator mis-associated chains such as a-(b)/2-c/2,
 * assembling different code than pMARS. Preserves pMARS precedence,
 * registers and eager logical evaluation; rejects malformed or overflowing
 * arithmetic. */
#define EVAL_MAX_DEPTH 128
#define EVAL_MAX_STEPS 100000UL

typedef struct {
    mars_t *mars;
    const char *cur;
    unsigned int depth;
    unsigned long steps;
    int error;
} expr_parser;

static long expression(expr_parser *, int);

static void spaces(expr_parser *p)
{
    while (isspace((unsigned char)*p->cur)) ++p->cur;
}

static int enter(expr_parser *p)
{
    if (p->error || p->depth >= EVAL_MAX_DEPTH || ++p->steps > EVAL_MAX_STEPS) {
        if (!p->error) p->error = BAD_EXPR;
        return 0;
    }
    ++p->depth;
    return 1;
}

static long number(expr_parser *p, int negative)
{
    unsigned long value = 0;
    unsigned long limit = (unsigned long)LONG_MAX + (negative ? 1UL : 0UL);
    while (isdigit((unsigned char)*p->cur)) {
        unsigned int digit = (unsigned int)(*p->cur++ - '0');
        if (value > (limit - digit) / 10UL) {
            p->error = BAD_EXPR;
            return 0;
        }
        value = value * 10UL + digit;
    }
    if (negative && value == (unsigned long)LONG_MAX + 1UL) return LONG_MIN;
    return negative ? -(long)value : (long)value;
}

static long primary(expr_parser *p)
{
    long value = 0;
    int ch, reg;
    if (!enter(p)) return 0;
    spaces(p);
    ch = (unsigned char)*p->cur;
    if (ch == '(') {
        ++p->cur;
        value = expression(p, 0);
        spaces(p);
        if (*p->cur == ')') ++p->cur;
        else p->error = BAD_EXPR;
    } else if (ch == '+' || ch == '-' || ch == '!') {
        ++p->cur;
        spaces(p);
        if (ch == '-' && isdigit((unsigned char)*p->cur))
            value = number(p, 1);
        else {
            value = primary(p);
            if (ch == '-') {
                if (value == LONG_MIN) p->error = BAD_EXPR;
                else value = -value;
            } else if (ch == '!') value = !value;
        }
    } else if (isdigit(ch)) {
        value = number(p, 0);
    } else if ((reg = toupper(ch)) >= 'A' && reg <= 'Z') {
        ++p->cur;
        spaces(p);
        if (*p->cur == '=' && p->cur[1] != '=') {
            ++p->cur;
            value = expression(p, 0);
            if (!p->error) p->mars->regAr[reg - 'A'] = value;
        } else value = p->mars->regAr[reg - 'A'];
    } else {
        p->error = BAD_EXPR;
    }
    --p->depth;
    return value;
}

static int read_operator(expr_parser *p, int *width, int *precedence)
{
    int ch = (unsigned char)*p->cur;
    *width = 1;
    *precedence = 3;
    switch (ch) {
    case '*': case '/': case '%': *precedence = 5; return ch;
    case '+': case '-': *precedence = 4; return ch;
    case '<': case '>':
        if (p->cur[1] == '=') { *width = 2; return ch == '<' ? LTE : GTE; }
        return ch;
    case '=': case '!':
        if (p->cur[1] == '=') { *width = 2; return ch == '=' ? EQUAL : NEQU; }
        return 0;
    case '&': case '|':
        if (p->cur[1] == ch) {
            *width = 2; *precedence = ch == '&' ? 2 : 1;
            return ch == '&' ? AND : OR;
        }
        return 0;
    default: return 0;
    }
}

static long arithmetic(expr_parser *p, long x, long y, int op)
{
    switch (op) {
    case '+':
        if ((y > 0 && x > LONG_MAX - y) || (y < 0 && x < LONG_MIN - y)) break;
        return x + y;
    case '-':
        if ((y < 0 && x > LONG_MAX + y) || (y > 0 && x < LONG_MIN + y)) break;
        return x - y;
    case '*':
        if (x > 0 ? (y > 0 ? x > LONG_MAX / y : y < LONG_MIN / x) :
            (x < 0 && (y > 0 ? x < LONG_MIN / y : y < 0 && x < LONG_MAX / y))) break;
        return x * y;
    case '/': case '%':
        if (!y) { p->error = DIV_ZERO; return 0; }
        if (x == LONG_MIN && y == -1) break;
        return op == '/' ? x / y : x % y;
    case AND: return x && y;
    case OR: return x || y;
    case EQUAL: return x == y;
    case NEQU: return x != y;
    case '<': return x < y;
    case '>': return x > y;
    case LTE: return x <= y;
    case GTE: return x >= y;
    }
    p->error = BAD_EXPR;
    return 0;
}

static long expression(expr_parser *p, int minimum)
{
    long left;
    int op, width, precedence;
    if (!enter(p)) return 0;
    left = primary(p);
    while (!p->error) {
        long right;
        spaces(p);
        op = read_operator(p, &width, &precedence);
        if (!op || precedence < minimum) break;
        if (++p->steps > EVAL_MAX_STEPS) { p->error = BAD_EXPR; break; }
        p->cur += width;
        right = expression(p, precedence + 1);
        if (!p->error) left = arithmetic(p, left, right, op);
    }
    --p->depth;
    return left;
}

/*--------------------*/
void
reset_regs(mars_t* mars)
{
    register int idx;

    for (idx = 0; idx < 26; ++idx)
        mars->regAr[idx] = 0L;
}

/*--------------------*/
int
eval_expr(mars_t* mars, char* expr, long* result)
{
    expr_parser p;
    long saved[26];
    int i;
    p.mars = mars; p.cur = expr; p.depth = 0; p.steps = 0; p.error = OK_EXPR;
    for (i = 0; i < 26; ++i) saved[i] = mars->regAr[i];
    *result = expression(&p, 0);
    spaces(&p);
    if (!p.error && *p.cur) p.error = BAD_EXPR;
    if (p.error) {
        *result = 0;
        for (i = 0; i < 26; ++i) mars->regAr[i] = saved[i];
    }
    mars->evalerr = p.error;
    return p.error;
}





#define toupper_(x) (toupper(x))

/* *************************** definitions ******************************* */

#define is_addr(ch)  pstrchr(addr_sym, (int) ch)
#define is_expr(ch)  pstrchr(expr_sym, (int) ch)
#define is_alpha(ch) (isalpha(ch) || (ch) == '_')

/* ********************************************************************** */

const char   *
pstrchr(const char* s, int c)
{
    do {
        if ((int) *s == c)
            return s;
    } while (*s++);

    return NULL;
}

/* ********************************************************************** */

char   *
pstrdup(s)
    char   *s;
{
    char   *p, *q;
    register int i;

    for (q = s, i = 0; *q; q++)
        i++;

    if ((p = (char *) MALLOC(sizeof(char) * (i + 1))) != NULL) {
        q = p;
        while (*s)
            *q++ = *s++;
        *q = '\0';
    }
    return p;
}

/* ********************************************************************** */

char   *
pstrcat(s1, s2)
    char   *s1, *s2;
{
    register char *p = s1;

    while (*p)
        p++;
    while (*s2)
        *p++ = *s2++;
    *p = '\0';

    return s1;
}

/* ********************************************************************** */

/* return src of char in charset. charset is a string */
uChar ch_in_set(char c, const char* s)
{
    char    cc;
    register char a;
    register uChar i;

    cc = c;
    for (i = 0; ((a = s[i]) != '\0') && (a != cc); i++);
    return (i);
}

/* ********************************************************************** */

/*
 * return src of str in charset. charset is a string set. case is significant
 */
uChar 
str_in_set(char* str, const char* s[])
{
    register uChar i;
    for (i = 0; *s[i] && strcmp(str, s[i]); i++);
    return (i);
}

/* ********************************************************************** */

/* return next char which is non-whitespace char */
uChar skip_space(char* str, uChar i)
{
    register uChar idx;
    idx = i;
    while (isspace(str[idx]))
        idx++;
    return (idx);
}

/* ********************************************************************** */

void 
to_upper(str)
    char   *str;
{
    while ((*str = toupper_(*str)) != '\0')
        str++;
}

/* ********************************************************************** */

/* Get token which depends on the first letter. token need to be allocated. */
int 
get_token(char* str, uChar* curIndex, char* myToken)
{
    register uChar src, dst = 0;
    register int ch;                /* int for ctype compliance */
    int     tokenType;

    src = skip_space(str, *curIndex);

    if (str[src])
        if (isdigit(ch = str[src])) {        /* Grab the whole digit */
            while (isdigit(str[src]))
                myToken[dst++] = str[src++];
            tokenType = NUMBTOKEN;
        }
    /* Grab the whole identifier. There would be special treatment to modifiers */
        else if (is_alpha(ch)) {
            for (; ((ch = str[src]) != '\0') && (is_alpha(ch) || isdigit(ch));)
                myToken[dst++] = str[src++];
            tokenType = CHARTOKEN;
        }
    /*
     * The following would accept only one single char. The order should
     * reflect the frequency of the symbols being used
     */
        else {
            /* Is operator symbol ? */
            if (is_expr(ch))
                tokenType = EXPRTOKEN;
            /* Is addressing mode symbol ? */
            else if (is_addr(ch))
                tokenType = ADDRTOKEN;
            /* Is concatenation symbol ? */
            /* currently force so that there is no double '&' */
            else if (ch == cat_sym)
                if (str[src + 1] == '&') {
                    myToken[dst++] = str[src++];
                    tokenType = EXPRTOKEN;
                } else
                    tokenType = APNDTOKEN;
            /* comment symbol ? */
            else if (ch == com_sym)
                tokenType = COMMTOKEN;
            /* field separator symbol ? */
            else if (ch == sep_sym)
                tokenType = FSEPTOKEN;
            /* modifier symbol ? */
            else if (ch == mod_sym)
                tokenType = MODFTOKEN;
            else if ((ch == '|') && (str[src + 1] == '|')) {
                myToken[dst++] = str[src++];
                tokenType = EXPRTOKEN;
            } else
                tokenType = MISCTOKEN;

            myToken[dst++] = str[src++];
        }
    else
        tokenType = NONE;

    myToken[dst] = '\0';
    *curIndex = src;

    return (tokenType);
}






int denormalize(mars_t* mars, int x) 
{
    if (x > (int)(mars->coresize/2)) return x - mars->coresize;
    else return x;
}


typedef mem_struct mem_st;

/* whether INITIALINST is displayed or not */
#define HIDE 0
#define SHOW 1

/* ******************************************************************** */
char* cellview(mars_t* mars, mem_struct* cell, char* outp)
{
    FIELD_T opcode, modifier;

    opcode = ((FIELD_T) (cell->opcode & 0xf8)) >> 3;
    modifier = (cell->opcode & 0x07);

    sprintf(outp, "%3s%c%-2s %c%6d, %c%6d %4s",
            opname[opcode],
            '.',
            modname[modifier],
            PM_INDIR_A(cell->A_mode) ? addr_sym[INDIR_A_TO_SYM(cell->A_mode)] : addr_sym[cell->A_mode], 
            denormalize(mars, cell->A_value),
            PM_INDIR_A(cell->B_mode) ? addr_sym[INDIR_A_TO_SYM(cell->B_mode)] : addr_sym[cell->B_mode],
            denormalize(mars, cell->B_value),
            "");

    return (outp);
}
/* ******************************************************************** */

void
disasm(mars_t* mars, mem_struct* cells, ADDR_T n, ADDR_T offset)
{
    ADDR_T  i;
    char    myBuf[MAXALLCHAR];

    if (SHOW && (offset >= 0) && (offset < n))
        fprintf(STDOUT, "%-6s %3s%3s  %6s\n", "", "ORG", "", "START");

    for (i = 0; i < n; ++i)
        fprintf(STDOUT, "%-6s %s\n", i == offset ? "START" : "",
                cellview(mars, (mem_struct *) cells + i, myBuf));

    if (SHOW && (offset >= 0) && (offset < n))
        fprintf(STDOUT, "%-6s %3s%3s  %6s\n", "", "END", "", "START");
}





/* ************************** Functions ***************************** */

static ref_st *
lookup(mars_t* mars, char* symn)
{
    ref_st *curtbl;
    grp_st *symtable;

    for (curtbl = mars->reftbl; curtbl; curtbl = curtbl->nextref)
        for (symtable = curtbl->grpsym; symtable;
             symtable = symtable->nextsym)
            if (!strcmp(symtable->symn, symn))
                return curtbl;

    return NULL;
}

/* ******************************************************************* */

static void
newtbl(mars_t* mars)
{
    ref_st *curtbl;
    if ((curtbl = (ref_st *) MALLOC(sizeof(ref_st))) != NULL) {
        curtbl->grpsym = NULL;
        curtbl->sline = NULL;
        curtbl->visit = FALSE;        /* needed to detect recursive reference */
        curtbl->nextref = mars->reftbl;
        mars->reftbl = curtbl;
    } else
        MEMORYERROR;
}

/* ******************************************************************* */

static grp_st *
addsym(mars_t* mars, char* symn, grp_st* curgroup)
{
    grp_st *symgrp;

    if ((symgrp = (grp_st *) MALLOC(sizeof(grp_st))) != NULL) {
        if ((symgrp->symn = pstrdup(symn)) != NULL)
            symgrp->nextsym = curgroup;
        else {
            FREE(symgrp);
            MEMORYERROR;
        }
    }

    return symgrp;
}

/* ******************************************************************* */

static void
addpredef(mars_t* mars, char* symn, U32_T value)
{
    grp_st *lsymtbl = NULL;
    line_st *aline;

    lsymtbl = addsym(mars, symn, lsymtbl);
    sprintf(mars->token, "%lu", (unsigned long) value);
    newtbl(mars);
    mars->reftbl->grpsym = lsymtbl;
    mars->reftbl->reftype = RTEXT;
    if (((aline = (line_st *) MALLOC(sizeof(line_st))) != NULL) &&
        ((aline->vline = pstrdup(mars->token)) != NULL)) {
        aline->nextline = NULL;
        mars->reftbl->sline = aline;
    } else
        MEMORYERROR;
}

/* ******************************************************************* */

static void
addpredefs(mars_t* mars)
{
    /* predefined constants */
    addpredef(mars, "CORESIZE", (U32_T) mars->coresize);
    addpredef(mars, "MAXPROCESSES", (U32_T) mars->processes);
    addpredef(mars, "MAXCYCLES", (U32_T) mars->cycles);
    addpredef(mars, "MAXLENGTH", (U32_T) mars->maxWarriorLength);
    addpredef(mars, "MINDISTANCE", (U32_T) mars->minsep);
    addpredef(mars, "VERSION", (U32_T) PMARSVER);
    addpredef(mars, "WARRIORS", (U32_T) mars->nWarriors);
    addpredef(mars, "ROUNDS", (U32_T) mars->rounds);
    addpredef(mars, "PSPACESIZE", (U32_T) mars->pspaceSize);
}

/* ******************************************************************* */

/* Add line, with sline and lline, it is possible to add line to multiple
   group of inst */
static void addline(mars_t* mars, char* vline, src_st* src, uShrt lspnt)
{
    line_st *temp;
    if ((temp = (line_st *) MALLOC(sizeof(line_st))) != NULL) {
        if ((temp->vline = pstrdup(vline)) != NULL) {
            temp->dbginfo = (mars->dbginfo ? TRUE : FALSE);
            temp->linesrc = src;
            temp->nextline = NULL;
            if (mars->sline[lspnt])                /* First come first serve */
                mars->lline[lspnt] = mars->lline[lspnt]->nextline = temp;
            else                        /* lline init depends on sline */
                mars->sline[lspnt] = mars->lline[lspnt] = temp;
        } else {
            FREE(temp);
            MEMORYERROR;
        }
    }
}

/* ******************************************************************* */

static src_st* addlinesrc(mars_t* mars, char* src, uShrt loc)
{
    src_st *alinesrc;

    if ((alinesrc = (src_st *) MALLOC(sizeof(src_st))) == NULL)
        MEMORYERROR;
    else {
        alinesrc->src = pstrdup(src);
        alinesrc->loc = loc;
        alinesrc->nextsrc = mars->srctbl;
        mars->srctbl = alinesrc;
    }

    return alinesrc;
}

/* ******************************************************************* */
/*
  typedef struct src_st {
  char   *src;
  struct src_st *nextsrc;
  uShrt   loc;
  }       src_st;
*/

void disposesrc(src_st* r) {
    while (r) {
        src_st* next = r->nextsrc;
        FREE(r->src);
        FREE(r);
        r = next;
    }
}

/*
  typedef struct line_st {
  char   *vline;
  FIELD_T dbginfo;
  src_st *linesrc;
  struct line_st *nextline;
  }       line_st;
*/
static void
disposeline(aline)
    line_st *aline;
{
    line_st *tmp;

    while ((tmp = aline) != NULL) {
        FREE(tmp->vline);
        /*disposesrc(tmp->linesrc);  *//* by martinus */
        /*tmp->linesrc = NULL;*/
        aline = aline->nextline;
        FREE(tmp);
    }
}

/* ******************************************************************* */

/*
  typedef struct grp_st {
  char   *symn;
  struct grp_st *nextsym;
  }       grp_st;
*/
static void
disposegrp(agrp)
    grp_st *agrp;
{
    grp_st *tmp;

    while ((tmp = agrp) != NULL) {
        FREE(tmp->symn);
        agrp = agrp->nextsym;
        FREE(tmp);
    }
}

/* ******************************************************************* */

/*
  typedef struct ref_st {
  grp_st *grpsym;
  line_st *sline;
  uShrt   value, visit;
  RType   reftype;
  struct ref_st *nextref;
  }       ref_st;
*/
static void
disposetbl(atbl, btbl)
    ref_st *atbl, *btbl;
{
    ref_st *tmp;

    while ((tmp = atbl) != btbl) {
        atbl = atbl->nextref;
        disposegrp(tmp->grpsym);
        disposeline(tmp->sline);  /* memory leak fix by martinus */
        FREE(tmp);
    }
}

/* ******************************************************************* */

/* clear all allocated mem */
static void
cleanmem(mars_t* mars)
{
    disposeline(mars->sline[0]);
    disposeline(mars->sline[1]);
    mars->sline[0] = mars->sline[1] = NULL;
    disposetbl(mars->reftbl, NULL);
    mars->reftbl = NULL;
    disposegrp(mars->symtbl);
    mars->symtbl = NULL;
    mars->symnum = 0;
}

/* ******************************************************************* */

/* Remove trailing comment from str */
static void
nocmnt(str)
    char   *str;
{
    while (*str && (*str != com_sym))
        str++;
    *str = '\0';
}

/* ******************************************************************* */


/* stst && wangsawm v0.4.0: output for different displays */
static void
textout(char* str)
{
    fputs(str, stderr);   /* str holds warrior text: never a format */
}

/* ******************************************************************* */

static void
errprn(mars_t* mars, errType code, line_st* aline, const char* arg)
{
    char abuf[MAXALLCHAR];

    mars->errorcode = PARSEERR;
    mars->errorlevel = SERIOUS;

    switch (code) {
    case ANNERR:
        strcpy(abuf, illegalAppendErr);
        mars->errorlevel = WARNING;
        break;
    case BUFERR:
        strcpy(abuf, bufferOverflowErr);
        break;
    case ERVERR:
        sprintf(abuf, illegalConcatErr, arg);
        break;
    case GRPERR:
        sprintf(abuf, tooManyLabelsErr, arg);
        break;
    case FORERR:
        strcpy(abuf, unopenedFORErr);
        break;
    case ROFERR:
        strcpy(abuf, unclosedROFErr);
        mars->errorlevel = WARNING;
        break;
    case M88ERR:
        sprintf(abuf, bad88FormatErr, arg);
        break;
    case ZLNERR:
        strcpy(abuf, noInstErr);
        mars->errorlevel = WARNING;
        break;
    case DLBERR:
        sprintf(abuf, discardLabelErr, arg);
        mars->errorlevel = WARNING;
        break;
    case TOKERR:
        sprintf(abuf, tokenErr, arg);
        break;
    case SNFERR:
        sprintf(abuf, undefinedSymErr, arg);
        break;
    case NUMERR:
        strcpy(abuf, expectNumberErr);
        break;
    case SYNERR:
        strcpy(abuf, syntaxErr);
        break;
    case LINERR:
        sprintf(abuf, tooManyInstrErr, arg);
        break;
    case EXPERR:
        sprintf(abuf, missingErr, arg);
        break;
    case RECERR:
        sprintf(abuf, recursiveErr, arg);
        break;
    case EVLERR:
        strcpy(abuf, badExprErr);
        break;
    case DIVERR:
        strcpy(abuf, divZeroErr);
        break;
    case OFLERR:
        strcpy(abuf, overflowErr);
        mars->errorlevel = WARNING;
        break;
    case NASERR:
        strcpy(abuf, missingAssertErr);
        mars->errorlevel = WARNING;
        break;
    case OFSERR:
        strcpy(abuf, badOffsetErr);
        mars->errorlevel = WARNING;
        break;
    case CATERR:
        sprintf(abuf, concatErr, arg);
        break;
    case DOEERR:
        strcpy(abuf, ignoreENDErr);
        mars->errorlevel = WARNING;
        break;
    case BASERR:
        strcpy(abuf, invalidAssertErr);
        mars->errorlevel = WARNING;
        break;
    case EXXERR:
        sprintf(abuf, tooMuchStuffErr, MAXINSTR);
        break;
    case PMARS_IGNORE:
        sprintf(abuf, extraTokenErr, arg);
        mars->errorlevel = WARNING;
        break;
    case APPERR:
        sprintf(abuf, improperPlaceErr, arg);
        break;
    case F88ERR:
        sprintf(abuf, invalid88Err, arg);
        break;
    case NOPERR:
        sprintf(abuf, incompleteOpErr, arg);
        break;
    case IDNERR:
        sprintf(abuf, redefinitionErr, arg);
        mars->errorlevel = WARNING;
        break;
    case UDFERR:
        sprintf(abuf, undefinedLabelErr, arg);
        mars->errorlevel = WARNING;
        break;
    case CHKERR:
        strcpy(abuf, assertionFailErr);
        break;
    case MISC:
        strcpy(abuf, arg);
        break;
    case FNFERR:
        sprintf(abuf, fileOpenErr, arg);
        break;
    case DSKERR:
        sprintf(abuf, fileReadErr, arg);
        break;
    case MLCERR:
        cleanmem(mars);                        /* refresh memory for fprintf and system */
        fprintf(stderr, notEnoughMemErr);
        strcpy(mars->errmsg, "out of memory while assembling");
        parse_abort(mars, PARSE_ABORT_MEMORY);
        break;
    }

    if (mars->errorlevel == WARNING)
        mars->warnum++;
    else
        mars->errnum++;

    if (aline) {

        int     i = 0;

        if (aline->linesrc == NULL)
            LOGICERROR;

        while ((i < mars->ierr) && ((mars->errkeep[i].loc != aline->linesrc->loc) ||
                                    (mars->errkeep[i].code != code)))
            i++;

        if (i == mars->ierr) {
            sprintf(mars->outs, "%s", mars->errorlevel == WARNING ? warning : error);
            textout(mars->outs);
            sprintf(mars->outs, inLine, aline->linesrc->loc, aline->linesrc->src);
            textout(mars->outs);
            sprintf(mars->outs, "        %s\n", abuf);
            textout(mars->outs);
            mars->errkeep[mars->ierr].num = 1;
            mars->errkeep[mars->ierr].loc = aline->linesrc->loc;
            mars->errkeep[mars->ierr++].code = code;
        } else
            mars->errkeep[i].num++;
    } else {
        sprintf(mars->outs, "%s:\n",
                mars->errorlevel == WARNING ? warning : error);

        textout(mars->outs);
        sprintf(mars->outs, "        %s\n", abuf);
        textout(mars->outs);
    }

    if (mars->ierr >= ERRMAX) {
        sprintf(mars->outs, tooManyMsgErr);
        textout(mars->outs);
        snprintf(mars->errmsg, sizeof mars->errmsg, "too many errors or warnings (%d); the last one: %.180s", ERRMAX, abuf);
        parse_abort(mars, PARSE_ABORT_ERRORS);
    }
    strcpy(mars->errmsg, abuf);
}

/* ******************************************************************* */

#define A_expr mars->buf
#define B_expr mars->buf2
#define vallen 8

/* ******************************************************************* */

/* Here is the automaton */
static void
automaton(mars_t* mars, char* expr, stateCol state, mem_struct* cell)
{
    uChar   idx = 0;
    char   *tmp;
    ref_st *atbl;

    switch (mars->laststate = state) {

    case S_OP:
        mars->statefine = FALSE;
        if (get_token(expr, &idx, mars->token) == CHARTOKEN) {
            to_upper(mars->token);
            if ((mars->opcode = str_in_set(mars->token, opname)) < OPNUM)
                automaton(mars, (char *) expr + idx, S_MOD_ADDR_EXP, cell);
            else if (mars->opcode < EQUOP)
                automaton(mars, (char *) expr + idx, S_EXPR, cell);
            else
/* This should be toggled as error. No label should appear at this point */
                LOGICERROR;
        } else
            errprn(mars, EXPERR, mars->aline, opcodeMsg);
        break;

    case S_MOD_ADDR_EXP:
        mars->statefine = FALSE;
        switch (get_token(expr, &idx, mars->token)) {
        case MODFTOKEN:
            automaton(mars, (char *) expr + idx, S_MODF, cell);
            break;
        case ADDRTOKEN:
            cell->A_mode = (FIELD_T) ch_in_set(*(mars->token), addr_sym);
            if (cell->A_mode > 4) {
                if (mars->SWITCH_8)
                    errprn(mars, M88ERR, mars->aline, "[*{}]");
                else
                    cell->A_mode = SYM_TO_INDIR_A(cell->A_mode);
            }
            automaton(mars, (char *) expr + idx, S_EXP_FS, cell);
            break;
        case NUMBTOKEN:
        case EXPRTOKEN:
            automaton(mars, expr, S_EXP_FS, cell);
            break;
        case CHARTOKEN:
            if ((atbl = lookup(mars, mars->token)) != NULL)
                if (atbl->visit)
                    errprn(mars, RECERR, mars->aline, mars->token);
                else if (atbl->reftype == RTEXT)
                    if (atbl->sline) {
                        atbl->visit = TRUE;
                        automaton(mars, atbl->sline->vline, S_MOD_ADDR_EXP, cell);
                        atbl->visit = FALSE;
                        automaton(mars, (char *) expr + idx, mars->laststate, cell);
                    } else
/* all slines should've been filled */
                        LOGICERROR;
                else if ((tmp = (char *) MALLOC(sizeof(char) * vallen)) != NULL) {
                    sprintf(tmp, "%d", (int) atbl->value - mars->line);
                    atbl->visit = TRUE;
                    automaton(mars, tmp, S_MOD_ADDR_EXP, cell);
                    FREE(tmp);
                    atbl->visit = FALSE;
                    automaton(mars, (char *) expr + idx, mars->laststate, cell);
                } else
                    MEMORYERROR;
            else if (!mars->token[1])
                automaton(mars, expr, S_EXP_FS, cell);
            else
                errprn(mars, SNFERR, mars->aline, mars->token);
            break;
        case NONE:
            break;
        default:
            errprn(mars, APPERR, mars->aline, mars->token);
        }
        break;

    case S_MODF:
        mars->statefine = FALSE;
        switch (get_token(expr, &idx, mars->token)) {
        case CHARTOKEN:
            to_upper(mars->token);
            if ((mars->modifier = str_in_set(mars->token, modname)) < MODNUM)
                automaton(mars, (char *) expr + idx, S_ADDR_EXP_A, cell);
            else
                errprn(mars, EXPERR, mars->aline, modifierMsg);
            break;
        case NONE:
            break;
        default:
            errprn(mars, EXPERR, mars->aline, modifierMsg);
        }
        break;

    case S_ADDR_EXP_A:
        mars->statefine = FALSE;
        switch (get_token(expr, &idx, mars->token)) {
        case ADDRTOKEN:
            cell->A_mode = (FIELD_T) ch_in_set(*(mars->token), addr_sym);
            if (cell->A_mode > 4) {
                if (mars->SWITCH_8)
                    errprn(mars, M88ERR, mars->aline, "[*{}]");
                else
                    cell->A_mode = SYM_TO_INDIR_A(cell->A_mode);
            }
            automaton(mars, (char *) expr + idx, S_EXP_FS, cell);
            break;
        case NUMBTOKEN:
        case EXPRTOKEN:
            automaton(mars, expr, S_EXP_FS, cell);
            break;
        case CHARTOKEN:
            if ((atbl = lookup(mars, mars->token)) != NULL)
                if (atbl->visit)
                    errprn(mars, RECERR, mars->aline, mars->token);
                else if (atbl->reftype == RTEXT)
                    if (atbl->sline) {
                        atbl->visit = TRUE;
                        automaton(mars, atbl->sline->vline, S_ADDR_EXP_A, cell);
                        atbl->visit = FALSE;
                        automaton(mars, (char *) expr + idx, mars->laststate, cell);
                    } else
/* all slines should've been filled */
                        LOGICERROR;
                else if ((tmp = (char *) MALLOC(sizeof(char) * vallen)) != NULL) {
                    sprintf(tmp, "%d", (int) atbl->value - mars->line);
                    atbl->visit = TRUE;
                    automaton(mars, tmp, S_ADDR_EXP_A, cell);
                    FREE(tmp);
                    atbl->visit = FALSE;
                    automaton(mars, (char *) expr + idx, mars->laststate, cell);
                } else
                    MEMORYERROR;
            else if (!mars->token[1])
                automaton(mars, expr, S_EXP_FS, cell);
            else
                errprn(mars, SNFERR, mars->aline, mars->token);
            break;
        case NONE:
            break;
        default:
            errprn(mars, EXPERR, mars->aline, aTerm);
        }
        break;

    case S_EXP_FS:
        switch (get_token(expr, &idx, mars->token)) {
        case FSEPTOKEN:
            automaton(mars, (char *) expr + idx, S_ADDR_EXP_B, cell);
            break;
        case ADDRTOKEN:
            if ((mars->token[0] != '>') && (mars->token[0] != '<') && (mars->token[0] != '*'))
                errprn(mars, APPERR, mars->aline, mars->token);
            else {
                if (!concat(A_expr, mars->token))
                    errprn(mars, BUFERR, mars->aline, "");
                mars->statefine = TRUE;
                automaton(mars, (char *) expr + idx, S_EXP_FS, cell);
            }
            break;
        case NUMBTOKEN:
            if (!concat(mars->token, " "))
                errprn(mars, BUFERR, mars->aline, "");
            /* FALLTHROUGH */
        case EXPRTOKEN:
            if (!concat(A_expr, mars->token))
                errprn(mars, BUFERR, mars->aline, "");
            mars->statefine = TRUE;
            automaton(mars, (char *) expr + idx, S_EXP_FS, cell);
            break;
        case CHARTOKEN:
            if ((atbl = lookup(mars, mars->token)) != NULL)
                if (atbl->visit)
                    errprn(mars, RECERR, mars->aline, mars->token);
                else if (atbl->reftype == RTEXT)
                    if (atbl->sline) {
                        atbl->visit = TRUE;
                        automaton(mars, atbl->sline->vline, S_EXP_FS, cell);
                        atbl->visit = FALSE;
                        automaton(mars, (char *) expr + idx, mars->laststate, cell);
                    } else
/* all slines should've been filled */
                        LOGICERROR;
                else if ((tmp = (char *) MALLOC(sizeof(char) * vallen)) != NULL) {
                    sprintf(tmp, "%d", (int) atbl->value - mars->line);
                    atbl->visit = TRUE;
                    automaton(mars, tmp, S_EXP_FS, cell);
                    FREE(tmp);
                    atbl->visit = FALSE;
                    automaton(mars, (char *) expr + idx, mars->laststate, cell);
                } else
                    MEMORYERROR;
            else if (!mars->token[1])        /* check if it's a register. */
                if (concat(A_expr, mars->token)) {
                    mars->statefine = TRUE;
                    automaton(mars, (char *) expr + idx, S_EXP_FS, cell);
                } else
                    errprn(mars, BUFERR, mars->aline, "");
            else
                errprn(mars, SNFERR, mars->aline, mars->token);
            break;
        case NONE:
            break;
        default:
            errprn(mars, APPERR, mars->aline, mars->token);
        }
        break;

    case S_ADDR_EXP_B:
        mars->statefine = FALSE;
        switch (get_token(expr, &idx, mars->token)) {
        case ADDRTOKEN:
            cell->B_mode = (FIELD_T) ch_in_set(*(mars->token), addr_sym);
            if (cell->B_mode > 4) {
                if (mars->SWITCH_8)
                    errprn(mars, M88ERR, mars->aline, "[*{}]");
                else
                    cell->B_mode = SYM_TO_INDIR_A(cell->B_mode);
            }
            automaton(mars, (char *) expr + idx, S_EXPR, cell);
            break;
        case NUMBTOKEN:
        case EXPRTOKEN:
            automaton(mars, expr, S_EXPR, cell);
            break;
        case CHARTOKEN:
            if ((atbl = lookup(mars, mars->token)) != NULL)
                if (atbl->visit)
                    errprn(mars, RECERR, mars->aline, mars->token);
                else if (atbl->reftype == RTEXT)
                    if (atbl->sline) {
                        atbl->visit = TRUE;
                        automaton(mars, atbl->sline->vline, S_ADDR_EXP_B, cell);
                        atbl->visit = FALSE;
                        automaton(mars, (char *) expr + idx, mars->laststate, cell);
                    } else
/* all slines should've been filled */
                        LOGICERROR;
                else if ((tmp = (char *) MALLOC(sizeof(char) * vallen)) != NULL) {
                    sprintf(tmp, "%d", (int) atbl->value - mars->line);
                    atbl->visit = TRUE;
                    automaton(mars, tmp, S_ADDR_EXP_B, cell);
                    FREE(tmp);
                    atbl->visit = FALSE;
                    automaton(mars, (char *) expr + idx, mars->laststate, cell);
                } else
                    MEMORYERROR;
            else if (!mars->token[1])
                automaton(mars, expr, S_EXPR, cell);
            else
                errprn(mars, SNFERR, mars->aline, mars->token);
            break;
        case NONE:
            break;
        default:
            errprn(mars, EXPERR, mars->aline, bTerm);
        }
        break;

    case S_EXPR:
        switch (get_token(expr, &idx, mars->token)) {
        case ADDRTOKEN:
            if ((mars->token[0] != '>') && (mars->token[0] != '<') && (mars->token[0] != '*'))
                errprn(mars, APPERR, mars->aline, mars->token);
            else {
                if (!concat(B_expr, mars->token))
                    errprn(mars, BUFERR, mars->aline, "");
                mars->statefine = TRUE;
                automaton(mars, (char *) expr + idx, S_EXPR, cell);
            }
            break;
        case NUMBTOKEN:
            if (!concat(mars->token, " "))
                errprn(mars, BUFERR, mars->aline, "");
            /* FALLTHROUGH */
        case EXPRTOKEN:
            if (!concat(B_expr, mars->token))
                errprn(mars, BUFERR, mars->aline, "");
            mars->statefine = TRUE;
            automaton(mars, (char *) expr + idx, S_EXPR, cell);
            break;
        case CHARTOKEN:
            if ((atbl = lookup(mars, mars->token)) != NULL)
                if (atbl->visit)
                    errprn(mars, RECERR, mars->aline, mars->token);
                else if (atbl->reftype == RTEXT)
                    if (atbl->sline) {
                        atbl->visit = TRUE;
                        automaton(mars, atbl->sline->vline, S_EXPR, cell);
                        atbl->visit = FALSE;
                        automaton(mars, (char *) expr + idx, S_EXPR, cell);
                    } else
/* all slines should've been filled */
                        LOGICERROR;
                else if ((tmp = (char *) MALLOC(sizeof(char) * vallen)) != NULL) {
                    if (mars->opcode < OPNUM)
                        sprintf(tmp, "%d", (int) atbl->value - mars->line);
                    else
                        sprintf(tmp, "%d", (int) atbl->value);
                    atbl->visit = TRUE;
                    automaton(mars, tmp, S_EXPR, cell);
                    FREE(tmp);
                    atbl->visit = FALSE;
                    automaton(mars, (char *) expr + idx, S_EXPR, cell);
                } else
                    MEMORYERROR;
            else if (!mars->token[1])        /* check for register use */
                if (concat(B_expr, mars->token)) {
                    mars->statefine = TRUE;
                    automaton(mars, (char *) expr + idx, S_EXPR, cell);
                } else
                    errprn(mars, BUFERR, mars->aline, "");
            else
                errprn(mars, SNFERR, mars->aline, mars->token);
            break;
        case NONE:
            break;
        default:
            errprn(mars, APPERR, mars->aline, mars->token);
        }
        break;
    }
}

/* ******************************************************************* */

/* ICWS'88 rules (pMARS -8, asm.c): only the '88 opcodes, the #, $, @ and <
 * modes, no modifiers, and the '88 operand formats. Called once the operands
 * are parsed, before the default modifier is chosen. */
static void
check_icws88(mars_t* mars, mem_struct* cell)
{
    switch (mars->opcode) {
    case DAT:
        if (((cell->A_mode != (FIELD_T) IMMEDIATE) &&
             (cell->A_mode != (FIELD_T) PREDECR)) ||
            ((cell->B_mode != (FIELD_T) IMMEDIATE) &&
             (cell->B_mode != (FIELD_T) PREDECR)))
            errprn(mars, F88ERR, mars->aline, "DAT [#<] [#<]");
        break;
    case MOV:
    case ADD:
    case SUB:
    case CMP:
        if (cell->B_mode == (FIELD_T) IMMEDIATE) {
            snprintf(mars->token, MAXALLCHAR, "%s [#$@<] [$@<]", opname[mars->opcode]);
            errprn(mars, F88ERR, mars->aline, mars->token);
        }
        break;
    case JMP:
    case JMZ:
    case JMN:
    case DJN:
    case SPL:
        if (cell->A_mode == (FIELD_T) IMMEDIATE) {
            snprintf(mars->token, MAXALLCHAR, "%s [$@<] [#$@<]", opname[mars->opcode]);
            errprn(mars, F88ERR, mars->aline, mars->token);
        }
        break;
    case MUL:
    case DIV:
    case MOD:
    case SEQ:
    case SNE:
    case NOP:
    case LDP:
    case STP:
        errprn(mars, M88ERR, mars->aline, opname[mars->opcode]);
        break;
    default:
        break;
    }

    if (mars->modifier != MODNUM)
        errprn(mars, M88ERR, mars->aline, ".");
    if ((cell->A_mode == (FIELD_T) POSTINC) ||
        (cell->B_mode == (FIELD_T) POSTINC))
        errprn(mars, M88ERR, mars->aline, ">");
}

static void
dfashell(mars_t* mars, char* expr, mem_struct* cell)
{
    cell->A_mode = (FIELD_T) ch_in_set('$', addr_sym);
    cell->B_mode = (FIELD_T) ch_in_set('$', addr_sym);
    mars->modifier = MODNUM;                /* marked as not used */
    A_expr[0] = B_expr[0] = '\0';

    mars->errorcode = SUCCESS;
    automaton(mars, expr, S_OP, cell);

    if (mars->opcode < OPNUM) {

/* This is also represented in a NONE case in automaton function call */
        if ((mars->statefine == FALSE) && (mars->errorcode == SUCCESS))
            errprn(mars, SYNERR, mars->aline, opname[mars->opcode]);

        else if (B_expr[0] == '\0')        /* If there's only one argument */
            switch (mars->opcode) {
            case DAT:                /* The default in DAT statement is #0 */
                cell->B_mode = cell->A_mode;
                strcpy(B_expr, A_expr);
                cell->A_mode = (FIELD_T) ch_in_set('#', addr_sym);
                strcpy(A_expr, "0");
                break;
            case SPL:                /* The default in SPL/JMP statement is $0 */
            case JMP:
            case NOP:
                cell->B_mode = (FIELD_T) ch_in_set('$', addr_sym);
                strcpy(B_expr, "0");
                break;
            default:
                errprn(mars, NOPERR, mars->aline, opname[mars->opcode]);        /* opcode < OPNUM */
            }

        if (mars->SWITCH_8)
            check_icws88(mars, cell);

        if (mars->modifier == MODNUM)        /* no modifier, pick default */
            switch (mars->opcode) {
            case DAT:
            case NOP:
                mars->modifier = (FIELD_T) mF;
                break;
            case MOV:
            case CMP:
            case SEQ:
            case SNE:
                if (cell->A_mode == (FIELD_T) IMMEDIATE)
                    mars->modifier = (FIELD_T) mAB;
                else if (cell->B_mode == (FIELD_T) IMMEDIATE)
                    mars->modifier = (FIELD_T) mB;
                else
                    mars->modifier = (FIELD_T) mI;
                break;
            case ADD:
            case SUB:
            case MUL:
            case DIV:
            case MOD:
                if (cell->A_mode == (FIELD_T) IMMEDIATE)
                    mars->modifier = (FIELD_T) mAB;
                else if (cell->B_mode == (FIELD_T) IMMEDIATE)
                    mars->modifier = (FIELD_T) mB;
                else
                    mars->modifier = (FIELD_T) mF;
                break;
            case LDP:
            case STP:
            case SLT:
                if (cell->A_mode == (FIELD_T) IMMEDIATE)
                    mars->modifier = (FIELD_T) mAB;
                else
                    mars->modifier = (FIELD_T) mB;
                break;
            default:
                mars->modifier = (FIELD_T) mB;
            }
        cell->opcode = (FIELD_T) (mars->opcode << 3) + mars->modifier;
    }
}

/* ******************************************************************* */

static int
normalize(mars_t* mars, long value)
{
    while (value >= (long) mars->coresize)
        value -= (long) mars->coresize;
    while (value < 0)
        value += (long) mars->coresize;
    return ((int) value);
}


/* ******************************************************************* */

#define SNIL 0
#define SLBL 1
#define SVAL 2
#define SCOM 3
#define SPSE 4
#define SFOR 5
#define SROF 6
#define SERR -1

/* ******************************************************************* */

static int
blkfor(mars_t* mars, char* expr, char* dest)
{
    int myEvalerr;
    line_st *cline;
    long    result;
    ref_st *atbl, *ptbl;
    grp_st *forSymGr;

    if (mars->symtbl) {
        forSymGr = addsym(mars, mars->symtbl->symn, NULL);
        if (mars->symtbl->nextsym) {
            newtbl(mars);
            mars->reftbl->reftype = RLABEL;
            mars->reftbl->grpsym = mars->symtbl->nextsym;
            mars->reftbl->value = mars->line;
        }
        /*disposegrp(mars->symtbl); */ /* memory leak fix by martinus */
        mars->symtbl = NULL;
        mars->symnum = 0;
    } else
        forSymGr = NULL;

    *dest = '\0';
    trav2(mars, expr, dest, SVAL);

    if ((myEvalerr = eval_expr(mars, dest, &result)) < OK_EXPR) {
        if (myEvalerr == DIV_ZERO)
            errprn(mars, DIVERR, mars->aline, "");
        else
            errprn(mars, EVLERR, mars->aline, "");
    } else if (result <= 0L) {
        if (myEvalerr == PMARS_OVERFLOW)
            errprn(mars, OFLERR, mars->aline, "");
        mars->statefine++;
    } else {
        if (myEvalerr == PMARS_OVERFLOW)
            errprn(mars, OFLERR, mars->aline, "");

        newtbl(mars);
        mars->reftbl->reftype = RSTACK;
        mars->reftbl->grpsym = forSymGr;
        mars->reftbl->visit = 1;
        atbl = mars->reftbl;

        cline = mars->aline;
        for (atbl->value = 1; mars->vcont && atbl->value <= (uShrt) result && mars->aline;
             atbl->value++)
            for (mars->aline = cline; mars->vcont;)
                if (mars->aline->nextline) {
                    int     r;

                    mars->aline = mars->aline->nextline;
                    *dest = '\0';
                    if ((r = trav2(mars, mars->aline->vline, dest, SNIL)) == SROF)
                        break;
                    else if (r == SCOM) {
                        addline(mars, dest, mars->aline->linesrc, mars->dspnt);
                        if (mars->dbginfo == 3)
                            mars->dbginfo = 0;
                    }
                } else {
                    errprn(mars, ROFERR, (line_st *) NULL, "");
                    mars->vcont = FALSE;
                }

        for (ptbl = NULL, atbl = mars->reftbl; atbl; ptbl = atbl, atbl = atbl->nextref)
            if (atbl->reftype == RSTACK)
                break;

        if (ptbl)
            ptbl->nextref = atbl->nextref;
        else
            mars->reftbl = atbl->nextref;

        disposetbl(atbl, atbl->nextref);
    }

    return SFOR;
}

/* ******************************************************************* */

static int
equtbl(mars_t* mars, char* expr)
{
    line_st *cline, *pline = NULL;
    uChar   i;

    if (mars->symtbl) {

        newtbl(mars);
        mars->reftbl->reftype = RTEXT;
        mars->reftbl->grpsym = mars->symtbl;
        mars->symtbl = NULL;
        mars->symnum = 0;

        if (((cline = (line_st *) MALLOC(sizeof(line_st))) != NULL) &&
            ((cline->vline = pstrdup(expr)) != NULL)) {
            cline->linesrc = mars->aline->linesrc;
            cline->nextline = NULL;
            pline = mars->reftbl->sline = cline;
        } else
            MEMORYERROR;

        while (mars->aline->nextline) {

            i = 0;
            get_token(mars->aline->nextline->vline, &i, mars->token);
            to_upper(mars->token);
            if (strcmp(mars->token, "EQU") == 0) {
                mars->aline = mars->aline->nextline;

                if (((cline = (line_st *) MALLOC(sizeof(line_st))) != NULL) &&
                    ((cline->vline = pstrdup((char *) mars->aline->vline + i)) != NULL)) {
                    cline->linesrc = mars->aline->linesrc;
                    cline->nextline = NULL;
                    pline = pline->nextline = cline;
                } else
                    MEMORYERROR;
            }
            else
                break;
        }
    } else
        errprn(mars, ANNERR, mars->aline, "");

    return SVAL;
}

/* ******************************************************************* */

static int equsub(mars_t* mars, char* expr, char* dest, int wdecl, ref_st* tbl)
{
    line_st *cline;

    tbl->visit = 1;
    cline = mars->aline;
    mars->aline = tbl->sline;
    wdecl = trav2(mars, mars->aline->vline, dest, wdecl);

    while (mars->aline->nextline && mars->vcont) {
        if (mars->statefine == 0)
            if (wdecl == SCOM) {
                addline(mars, dest, mars->aline->linesrc, mars->dspnt);
                if (mars->dbginfo == 3)
                    mars->dbginfo = 0;
            }
        mars->aline = mars->aline->nextline;
        *dest = '\0';
        wdecl = trav2(mars, mars->aline->vline, dest, SNIL);
    }

    mars->aline = cline;
    if (isspace(*expr))
        concat(dest, " ");

    tbl->visit = 0;
    return trav2(mars, expr, dest, wdecl);
}

/* ******************************************************************* */

/* recursively traverse the buffer */
/* buf[] has to be "" */
static int trav2(mars_t* mars, char* buffer, char* dest, int wdecl)
{
    int myEvalerr;
    uChar   idxp = 0;
    ref_st *tbl;

    switch (get_token(buffer, &idxp, mars->token)) {

    case NONE:
        return wdecl;

    case COMMTOKEN:
        if ((wdecl == SNIL) && (mars->statefine == 0)) {

            uChar   idx;

            idx = idxp;
            get_token(buffer, &idx, mars->token);
            to_upper(mars->token);
            if (strcmp(mars->token, "ASSERT") == 0) {
                long    result;

                trav2(mars, (char *) buffer + idx, dest, SVAL);

                if ((myEvalerr = eval_expr(mars, dest, &result)) < OK_EXPR)
                    errprn(mars, BASERR, mars->aline, "");
                else {
                    if (myEvalerr == PMARS_OVERFLOW)
                        errprn(mars, OFLERR, mars->aline, "");
                    mars->noassert = FALSE;
                    if (result == 0L)
                        errprn(mars, CHKERR, mars->aline, "");
                }
            }
        }
        return wdecl;

    case CHARTOKEN:

        strcpy(mars->buf, mars->token);
        to_upper(mars->buf);

        if (strcmp(mars->buf, "ROF") == 0)
            if (mars->statefine)
                mars->statefine--;
            else if (wdecl <= SLBL)
                return SROF;
            else
                errprn(mars, APPERR, mars->aline, mars->token);

        else if (strcmp(mars->buf, "FOR") == 0)
            if (mars->statefine)
                mars->statefine++;
            else if (wdecl <= SLBL)
                return blkfor(mars, (char *) buffer + idxp, dest);
            else
                errprn(mars, APPERR, mars->aline, mars->token);

        else if (strcmp(mars->token, "CURLINE") == 0)
            if (mars->statefine)
                return SNIL;
            else if (wdecl > SLBL) {
                sprintf(mars->buf, "%d", mars->line);
                if (isspace(buffer[idxp]))
                    concat(mars->buf, " ");
                if (concat(dest, mars->buf))
                    return (trav2(mars, (char *) buffer + idxp, dest, wdecl));
                else
                    errprn(mars, BUFERR, mars->aline, "");
            } else
                errprn(mars, MISC, mars->aline, CURLINEErr);

        else if (strcmp(mars->buf, "EQU") == 0)
            if (mars->statefine)
                return SNIL;
            else if (wdecl <= SLBL)
                return equtbl(mars, (char *) buffer + idxp);
            else
                errprn(mars, APPERR, mars->aline, mars->token);

        else if ((mars->opcode = str_in_set(mars->buf, opname)) < EQUOP)
            if (mars->statefine)
                return SNIL;

            else if (wdecl <= SLBL) {

                uChar   j, op;

                for (j = 0; mars->buf[j]; j++);

                while (buffer[idxp] && !isspace(buffer[idxp]))
                    mars->buf[j++] = buffer[idxp++];

                if (isspace(buffer[idxp])) {
                    mars->buf[j++] = ' ';
                    mars->buf[j] = '\0';
                }
                if (!concat(dest, mars->buf))
                    errprn(mars, BUFERR, mars->aline, "");

                else {
                    op = mars->opcode;
                    if ((wdecl = trav2(mars, (char *) buffer + idxp, dest,
                                       op < OPNUM ? SVAL : SPSE)) != SERR) {

                        if (mars->symtbl) {
                            newtbl(mars);
                            mars->reftbl->reftype = RLABEL;
                            mars->reftbl->value = mars->line;
                            mars->reftbl->grpsym = mars->symtbl;
                            mars->symtbl = NULL;
                            mars->symnum = 0;
                        }
                        if (op < OPNUM) {
                            mars->line++;
                            if (mars->dbginfo == 2)
                                mars->dbginfo++;
                        } else if (op == ENDOP)
                            mars->vcont = FALSE;

                        return SCOM;
                    } else
                        return SERR;
                }
            } else
                errprn(mars, APPERR, mars->aline, mars->token);

        else if (mars->statefine == 0) {

            char    tmp = 1;

            while ((buffer[idxp] == cat_sym) && (isalpha(buffer[idxp + 1])) &&
                   (idxp++, get_token(buffer, &idxp, mars->buf) == CHARTOKEN) && tmp)
                if (((tbl = lookup(mars, mars->buf)) != NULL) && (tbl->reftype == RSTACK)) {
                    sprintf(mars->buf, "%02u", (unsigned int) tbl->value);
                    if (!concat(mars->token, mars->buf))
                        errprn(mars, BUFERR, mars->aline, "");
                } else {
                    errprn(mars, CATERR, mars->aline, mars->buf);
                    tmp = 0;
                }

            if ((tbl = lookup(mars, mars->token)) != NULL)
                if (tbl->reftype == RTEXT)
                    if (tbl->visit)
                        errprn(mars, RECERR, mars->aline, mars->token);
                    else
                        return equsub(mars, (char *) buffer + idxp, dest, wdecl, tbl);

                else if (wdecl > SLBL) {
                    if (tbl->reftype == RSTACK)
                        sprintf(mars->buf, "%02u", (unsigned int) tbl->value);
                    else if (wdecl == SPSE)
                        sprintf(mars->buf, "%d", tbl->value);        /* absolute value */
                    else
                        sprintf(mars->buf, "%d", tbl->value - mars->line);        /* relative value */

                    if (isspace(buffer[idxp]))
                        concat(mars->buf, " ");

                    if (concat(dest, mars->buf))
                        return (trav2(mars, (char *) buffer + idxp, dest, wdecl));
                    else
                        errprn(mars, BUFERR, mars->aline, "");
                } else
                    errprn(mars, IDNERR, mars->aline, mars->token);

            else if (wdecl <= SLBL) {
                if (mars->symnum < GRPMAX) {
                    mars->symtbl = addsym(mars, mars->token, mars->symtbl);
                    mars->symnum++;
                } else
                    errprn(mars, GRPERR, mars->aline, mars->token);

                if (buffer[idxp] == cln_sym)        /* ignore a colon after a line-label */
                    idxp++;

                /* traverse the rest of buffer */
                return trav2(mars, (char *) buffer + idxp, dest, SLBL);
            } else {
                if (isspace(buffer[idxp]))
                    concat(mars->token, " ");
                if (concat(dest, mars->token))
                    return (trav2(mars, (char *) buffer + idxp, dest, wdecl));
                else
                    errprn(mars, BUFERR, mars->aline, "");
            }
        } else
            return trav2(mars, (char *) buffer + idxp, dest, SNIL);
        break;
    default:
        if (mars->statefine)
            return SNIL;
        else if (wdecl <= SLBL)
            errprn(mars, TOKERR, mars->aline, mars->token);
        else {
            if (concat(dest, mars->token))
                return trav2(mars, (char *) buffer + idxp, dest, wdecl);
            else
                errprn(mars, BUFERR, mars->aline, "");
        }
    }
    return SERR;
}

/* ******************************************************************* */

/* collect and expand equ */
static void expand(mars_t* mars, uShrt sspnt)
{
    mars->dspnt = 1 - sspnt;
    disposeline(mars->sline[mars->dspnt]);
    mars->sline[mars->dspnt] = NULL;

    mars->vcont = TRUE;
    mars->statefine = 0;
    mars->linemax = (uShrt) mars->maxWarriorLength + LEXCMAX;

    mars->aline = mars->sline[sspnt];
    while (mars->aline && mars->vcont) {
        mars->buf2[0] = '\0';
        switch (trav2(mars, mars->aline->vline, mars->buf2, SNIL)) {
        case SCOM:
            addline(mars, mars->buf2, mars->aline->linesrc, mars->dspnt);
            if (mars->dbginfo == 3)
                mars->dbginfo = 0;
            break;
        case SFOR:
            break;
        case SROF:
            errprn(mars, FORERR, mars->aline, "");
        }
        mars->aline = mars->aline->nextline;
    }
}

/* ******************************************************************* */

static char stdinstart = 0;


/****************************************************/
/* martinus */
/****************************************************/

int globalswitch_warrior(mars_t* mars, warrior_struct* w, char* str, uShrt idx, uShrt loc, uShrt lspnt) 
{
    uChar   i;
    i = (uChar) idx;

    get_token(str, &i, mars->token);
    to_upper(mars->token);

    if (!strcmp(mars->token, "REDCODE") && i == idx + 7)        /* no leading spaces */
        return -1;

    while (isspace(str[i]))
        i++;

    if (strcmp(mars->token, "NAME") == 0) {
        FREE(w->name);
        if (str[i] == '\0')
            w->name = pstrdup(unknown);
        else
            w->name = pstrdup((char *) str + i);
    } else if (strcmp(mars->token, "AUTHOR") == 0) {
        FREE(w->authorName);
        if (str[i] == '\0')
            w->authorName = pstrdup(anonymous);
        else
            w->authorName = pstrdup((char *) str + i);
    } else if (strcmp(mars->token, "DATE") == 0) {
        FREE(w->date);
        if (str[i] == '\0')
            w->date = pstrdup("");
        else
            w->date = pstrdup((char *) str + i);
    } else if (strcmp(mars->token, "VERSION") == 0) {
        FREE(w->version);
        if (str[i] == '\0')
            w->version = pstrdup("");
        else
            w->version = pstrdup((char *) str + i);
    } else if (str_in_set(mars->token, swname) < SWNUM) {
        nocmnt(str + i);                /* don't remove first comment */
        addline(mars, str, addlinesrc(mars, str, loc), lspnt);
    }
    return 0;
}




void encode_warrior(mars_t* mars, warrior_struct* w, uShrt sspnt)
{
    int evalerrA, evalerrB;
    long    resultA, resultB;
    mem_struct *base;

/*  if (line <= MAXINSTR) { */

    if (mars->line > (uShrt) mars->maxWarriorLength) {
        sprintf(mars->buf, "%ld", mars->line - mars->maxWarriorLength);
        errprn(mars, LINERR, (line_st *) NULL, mars->buf);
    }
    w->instLen = mars->line;

    if (mars->line)
        if ((w->instBank = base = (mem_struct *)
             MALLOC((mars->line + 1) * sizeof(mem_struct))) != NULL) {
            for (mars->aline = mars->sline[sspnt], mars->line = 0; mars->aline; mars->aline = mars->aline->nextline) {
                dfashell(mars, mars->aline->vline, (mem_struct *) base + mars->line);
                if (mars->errnum == 0) {
                    if (*A_expr == '\0')
                        strcpy(A_expr, "0");
                    if (*B_expr == '\0')
                        strcpy(B_expr, "0");

                    if ((mars->opcode == ENDOP) || (mars->opcode == ORGOP)
#ifdef SHARED_PSPACE
                        || (mars->opcode == PINOP)
#endif
                        )
                        if ((evalerrA = eval_expr(mars, B_expr, &resultB)) < OK_EXPR) {
                            if (evalerrA == DIV_ZERO)
                                errprn(mars, DIVERR, mars->aline, "");
                            else
                                errprn(mars, EVLERR, mars->aline, "");
                        } else {                /* by absolute */
                            if (evalerrA == PMARS_OVERFLOW)
                                errprn(mars, OFLERR, mars->aline, "");

                            if ((mars->opcode == ORGOP || mars->opcode == PINOP) && mars->SWITCH_8)
                                errprn(mars, M88ERR, mars->aline, opname[mars->opcode]);

                            if (mars->opcode == ORGOP)
                                w->offset = normalize(mars, resultB);
#ifdef SHARED_PSPACE
                            else if (mars->opcode == PINOP) {
                                w->pSpaceIDNumber = resultB;        /* not an address, no
                                                                     * need to normalize */
                                w->pSpaceIndex = PIN_APPEARED;        /* to indicate PIN has
                                                                       * been set */
                            }
#endif
                            else if (resultB) {
                                if (w->offset)
                                    errprn(mars, DOEERR, mars->aline, "");
                                else
                                    w->offset = normalize(mars, resultB);
                            }
                            /* else ignore 'end' with parameter == 0L */
                        }
                    else if ((evalerrA = eval_expr(mars, A_expr, &resultA)) < OK_EXPR) {
                        if (evalerrA == DIV_ZERO)
                            errprn(mars, DIVERR, mars->aline, "");
                        else
                            errprn(mars, EVLERR, mars->aline, "");
                    } else if ((evalerrB = eval_expr(mars, B_expr, &resultB)) < OK_EXPR) {
                        if (evalerrB == DIV_ZERO)
                            errprn(mars, DIVERR, mars->aline, "");
                        else
                            errprn(mars, EVLERR, mars->aline, "");
                    } else {
                        if (evalerrA == PMARS_OVERFLOW || evalerrB == PMARS_OVERFLOW)
                            errprn(mars, OFLERR, mars->aline, "");
                        base[mars->line].A_value = (ADDR_T) normalize(mars, resultA);
                        base[mars->line].B_value = (ADDR_T) normalize(mars, resultB);
                        if ((base[mars->line++].debuginfo = (FIELD_T) mars->aline->dbginfo) != 0) {
                            /* debugState = BREAK; */
                            /* not supported */
                        }
                    }
                }
            }
            if ((w->offset < 0) ||
                (w->offset >= w->instLen))
                errprn(mars, OFSERR, (line_st *) NULL, "");
        } else
            MEMORYERROR;
    else
        errprn(mars, ZLNERR, (line_st *) NULL, "");
    /*
      } else
      errprn(mars, EXXERR, (line_st *) NULL, "");
    */
}



static int assemble_file(mars_t* mars, char* fName, warrior_struct* w)
{
    FILE   *infp;
    uChar   cont = TRUE, conLine = FALSE, i;
    uShrt   lines;                /* logical and physical lines */
    uShrt   spnt = 0;                /* index/pointer to sline and lline */

    /* release all allocated memory */
    mars->errorlevel = WARNING;
    mars->errorcode = SUCCESS;
    *(mars->errmsg) = '\0';
    mars->errnum = mars->warnum = 0;

    mars->pass = 0;

    mars->srctbl = NULL;
    mars->sline[0] = mars->sline[1] = NULL;
    mars->reftbl = NULL;
    mars->symtbl = NULL;
    mars->symnum = 0;

    lines = 0;
    mars->ierr = 0;

    if (mars->errkeep == NULL) {
        if ((mars->errkeep = (err_st *) MALLOC(sizeof(err_st) * ERRMAX)) == NULL)
            MEMORYERROR;
    }

    w->name = pstrdup(unknown);
    w->authorName = pstrdup(anonymous);
    w->date = pstrdup("");
    w->version = pstrdup("");
    w->pSpaceIndex = UNSHARED;        /* tag */

    /* These two inits turn out to be neccessary */
    w->instBank = NULL;
    w->instLen = 0;
    mars->dbgproceed = TRUE;
    mars->dbginfo = FALSE;
    mars->noassert = TRUE;

    addpredefs(mars);

    /* stage 1: file reading module */
    if ((*fName == '\0') || (infp = fopen(fName, "r")) != NULL) {

        char    pstart;

        if (*fName == '\0') {
            infp = stdin;
            pstart = stdinstart;
        } else {
            pstart = 0;
            mars->parseFile = infp;        /* closed by parse_abort_cleanup() on an abort */
        }

        lines = 0;
        mars->aline = NULL;

        while (cont) {

            /*
             * Read characters until newline or EOF encountered. newline is
             * excluded. Need to be non-strict boolean evaluation
             */
            *(mars->buf) = '\0';
            i = 0;                        /* pointer to line buffer start */

            do {
                if (fgets(mars->buf + i, MAXALLCHAR - i, infp)) {
                    for (; mars->buf[i]; i++)
                        if (mars->buf[i] == '\n' || mars->buf[i] == '\r')
                            break;
                    mars->buf[i] = 0;
                    if (mars->buf[i - 1] == '\\') {        /* line continued */
                        conLine = TRUE;
                        mars->buf[--i] = 0;        /* reset */
                    } else
                        conLine = FALSE;
                } else if (ferror(infp)) {
                    errprn(mars, DSKERR, (line_st *) NULL, fName);
                    mars->parseFile = NULL;
                    fclose(infp);
                    return PARSEERR;
                } else
                    cont = (feof(infp) == 0);
            } while (conLine == TRUE);
            lines++;
            i = 0;

            switch (get_token(mars->buf, &i, mars->token)) {
                /*
                 * COMMTOKEN before any non-whitespace chars may contains switches.
                 * We treat them first and therefore we don't have to save it in
                 * sline
                 */
            case COMMTOKEN:
                if ((globalswitch_warrior(mars, w, mars->buf, (uShrt) i, lines, spnt))) {        /* REDCODE? */
                    switch (pstart) {
                    case 0:
                        disposeline(mars->sline[spnt]);
                        mars->sline[spnt] = mars->lline[spnt] = NULL;
                        pstart++;
                        break;
                    case 1:
                        pstart++;
                        /* fallthru */
                    case 2:
                        cont = 0;
                        break;
                    }
				}
                break;
				
            case NONE:
                break;
				
            default:
                nocmnt(mars->buf);                /* saving some space */
                addline(mars, mars->buf, addlinesrc(mars, mars->buf, lines), spnt);
                break;
            }
        } /* !while */
        if (pstart)
            pstart--;

        if (*fName) {
            mars->parseFile = NULL;
            fclose(infp);
        } else
            stdinstart = pstart;        /* save value for next stdin reference */

        mars->line = 0;
        expand(mars, spnt);

        if (mars->symtbl) {
            grp_st *tmp;

            *(mars->buf) = '\0';
            for (tmp = mars->symtbl; tmp; tmp = tmp->nextsym) {
                if (*(mars->buf))
                    if (!concat(mars->buf, " "))
                        break;
                if (!concat(mars->buf, tmp->symn))
                    break;
            }

            errprn(mars, DLBERR, (line_st *) NULL, mars->buf);
            disposegrp(mars->symtbl);        /* discount any mars->symtbl with empty reference */
            mars->symtbl = NULL;
            mars->symnum = 0;
        }
        spnt = 1 - spnt;
        mars->pass++;

        if (mars->noassert)
            errprn(mars, NASERR, (line_st *) NULL, "");

        /* printf("Entering pass 2 (parsing and loading)\n"); */
        encode_warrior(mars, w, spnt);

        mars->dbginfo = FALSE;
        mars->dbgproceed = TRUE;
        /* release all allocated memory */
        cleanmem(mars);
        while (mars->srctbl) {
            src_st *tmp = mars->srctbl;
            mars->srctbl = mars->srctbl->nextsrc;
            FREE(tmp->src);
            FREE(tmp);
        }

        if (mars->errnum) {
            FREE(w->instBank);
            w->instLen = 0;
        }
        if (mars->errnum) {
            sprintf(mars->outs, errNumMsg, mars->errnum);
            textout(mars->outs);
        }
        if (mars->warnum) {
            sprintf(mars->outs, warNumMsg, mars->warnum);
            textout(mars->outs);
        }
        while (mars->ierr)
            if (mars->errkeep[--(mars->ierr)].num > 1) {
                sprintf(mars->outs, duplicateMsg, mars->errkeep[mars->ierr].loc, mars->errkeep[mars->ierr].num);
                textout(mars->outs);
            }
        if (mars->errnum + mars->warnum) {
            sprintf(mars->outs, "\n");
            textout(mars->outs);
        }
    } else
        errprn(mars, FNFERR, (line_st *) NULL, fName);

    if (mars->errnum)
        mars->errorcode = PARSEERR;
    else
        mars->errorcode = SUCCESS;
    reset_regs(mars);
    return (mars->errorcode);
}


/* exhaust related */




void panic(const char *msg)
{
    /*  fprintf(stderr, "%s: ", prog_name );*/
    fprintf(stderr, "%s", msg );
    exit(1);
}


void usage(void)
{
    printf("exMARS %s — AI-assisted fork of exMARS 0.01\n", EXMARS_VERSION);
    printf("usage: exmars [opts] warriors...\n");
    printf("      exmars --version\n");
    printf("opts: -r <rounds>, -c <cycles>, -F <pos>, -s <coresize>,\n"
           "      -p <maxprocs>, -l <maxlen>, -d <minsep>, -P, -8, -bk, -X\n"
           "      -8: enforce ICWS'88 rules when assembling (pMARS -8)\n"
           "      -P: every placement in both starting orders (pMARS -P); without -r,\n"
           "          2*(coresize-2*minsep+1) rounds play each once\n"
           "      -X: disable default safe early ties; preserve final core/queues\n      -E: enable safe early ties (default; compatibility option)\n");
#if EXMARS_FIXED_CORESIZE || EXMARS_FIXED_PROCESSES || EXMARS_FIXED_CYCLES
    printf("compiled constants (0=dynamic): core=%u processes=%lu cycles=%lu\n",
           (unsigned)EXMARS_FIXED_CORESIZE, (unsigned long)EXMARS_FIXED_PROCESSES,
           (unsigned long)EXMARS_FIXED_CYCLES);
#endif
    exit(1);
}


void output_results(mars_t* mars)
{
    unsigned int i;
    unsigned int j;

    if (mars->nWarriors == 2 && !mars->isMultiWarriorOutput) {
        printf("%ld %ld\n", mars->results[0*(mars->nWarriors+1) + 1], mars->results[0*(mars->nWarriors+1) + 2]);
        printf("%ld %ld\n", mars->results[1*(mars->nWarriors+1) + 1], mars->results[1*(mars->nWarriors+1) + 2]);
    } else {
        for (i=0; i<mars->nWarriors; i++) {
            for (j=1; j<=mars->nWarriors; j++) {
                printf("%ld ", mars->results[i*(mars->nWarriors+1) + j]);
            }
            printf("%ld\n", mars->results[i*(mars->nWarriors+1) + 0]);
        }
    }
}


/* The command-line tool's check: exits with the message. */
void check_sanity(mars_t* mars)
{
    const char *error = sanity_error(mars);
    if (error) panic(error);
}


/*
 * parse options
 */
void readargs(int argc, char** argv, mars_t* mars) {
    int n;
    char c;
    int cix;
    int tmp;
    int roundsGiven = 0;
    warriorNames_t* currWarrior = NULL;

    mars->warriorNames = NULL;
    mars->nWarriors = 0;
    n = 1;
    while ( n < argc ) {
        cix = 0;
        c = argv[n][cix++];
        if ( c == '-' && argv[n][1] ) {
            do {
                c = argv[n][cix++];
                if (c)
                    switch (c) {

                    case 'k': break;
                    case 'b': break;
                    case 'm': mars->isMultiWarriorOutput = 1; break;
                    case 'E': mars->earlyExit = 1; break;
                    case 'X': mars->earlyExit = 0; break;
                    case 'P': mars->permutate = 1; break;
                    case '8': mars->SWITCH_8 = 1; break;

                    case 'F':
                        if ( n == argc-1 || !isdigit(argv[n+1][0]) )
                            panic( "bad argument for option -F\n");
                        c = 0;
                        mars->fixedPosition = atoi( argv[++n] );
                        break;

                    case 's':
                        if ( n == argc-1 || !isdigit(argv[n+1][0]) )
                            panic( "bad argument for option -s\n");
                        c = 0;
                        mars->coresize = atoi( argv[++n] );
                        if ( mars->coresize <= 0 )
                            panic( "core size must be > 0\n");
                        break;

                    case 'l':
                        if (n == argc-1 || !isdigit(argv[n+1][0]))
                            panic("bad argument for option -l\n");
                        c = 0;
                        mars->maxWarriorLength = atoi(argv[++n]);
                        if ((int)mars->maxWarriorLength <= 0)
                            panic("maximum warrior length must be > 0\n");
                        break;

                    case 'd':
                        if ( n == argc-1 || !isdigit(argv[n+1][0]) )
                            panic( "bad argument for option -d\n");
                        c = 0;
                        mars->minsep = atoi( argv[++n] );
                        if ( (int)mars->minsep <= 0 )
                            panic( "minimum warrior separation must be > 0\n" );
                        break;

                    case 'p':
                        if ( n == argc-1 || !isdigit(argv[n+1][0]) )
                            panic( "bad argument for option -p\n");
                        c = 0;
                        mars->processes = atoi( argv[++n] );
                        if ( mars->processes <= 0 )
                            panic( "max processes must be > 0\n" );
                        break;

                    case 'r':
                        if ( n == argc-1 || !isdigit(argv[n+1][0]) )
                            panic( "bad argument for option -r\n");
                        c = 0;
                        tmp = atoi( argv[++n] );
                        if ( tmp < 0 )
                            panic( "can't do a negative number of rounds!\n" );
                        mars->rounds = tmp;
                        roundsGiven = 1;
                        break;
                    case 'c':
                        if ( n == argc-1 || !isdigit(argv[n+1][0]) )
                            panic( "bad argument for option -c\n");
                        c = 0;
                        mars->cycles = atoi( argv[++n] );
                        if ( mars->cycles <= 0 )
                            panic( "cycles must be > 0\n" );
                        break;
                    default:
                        sprintf(mars->errmsg,"unknown option '%c'\n", c);
                        panic(mars->errmsg);
                    }
            } while (c);

        } else /* it's a file name */ {
            /*
              if (NWarriors == MAX_WARRIORS) {
              panic("too many warriors\n");
              }
            */
            mars->nWarriors++;
            if (mars->warriorNames == NULL) {
                mars->warriorNames = (warriorNames_t*)malloc(sizeof(warriorNames_t));
                currWarrior = mars->warriorNames;
            }
            else { 
                currWarrior->next = (warriorNames_t*)malloc(sizeof(warriorNames_t));
                currWarrior = currWarrior->next;
            }
            currWarrior->warriorName = argv[n];
            currWarrior->next = NULL;
        }
        n++;
    }

    if ( mars->nWarriors == 0 )
        usage();
    if (mars->permutate) {
        /* As pMARS: before assembly, so ROUNDS is predefined to the count. */
        if (mars->nWarriors != 2)
            panic(permutateMultiWarrior);
        if (!roundsGiven)
            mars->rounds = mars_permutations(mars);
    }
}


mars_t* init(int argc, char** argv) {
    mars_t* mars = 0;
    mars = (mars_t*)malloc(sizeof(mars_t));
    memset(mars, 0, sizeof(mars_t));
    mars->earlyExit = 1;
    mars->rounds = 1;
    mars->cycles = EXMARS_INITIAL_CYCLES;
    mars->coresize = EXMARS_INITIAL_CORE;
    mars->processes = EXMARS_INITIAL_PROCESSES;
    mars->maxWarriorLength = EXMARS_DEFAULT_LENGTH;
    mars->seed = rng((s32_t)time(0)*0x1d872b41);
    mars->minsep = EXMARS_DEFAULT_MINSEP;
    mars->nWarriors = 2;
    /* pmars */
    mars->errorcode = SUCCESS;
    mars->errorlevel = WARNING;
    mars->saveOper = 0;
    mars->errmsg[0] = '\0';                /* reserve for future */

    readargs(argc, argv, mars);
    {
        const char *fixed_error = sim_fixed_settings_error(mars);
        if (fixed_error) panic(fixed_error);
    }
    if (!sim_alloc_bufs(mars)) {
        printf("memory alloc failed.\n");
        exit(1);
    }
    return mars;
}

/* convert pmars parsed warriors to exhaust's format */
void pmars2exhaust(mars_t* mars, warrior_struct** warriors, int wCount)
{
    int currWarrior;
    for(currWarrior=0; currWarrior<wCount; ++currWarrior) {
        int i;
        warrior_struct* w = warriors[currWarrior];
            
        /* exhaust */
        warrior_t* warrior = &(mars->warriors[currWarrior]);
        insn_t* in = NULL;
        warrior->start = w->offset;
        warrior->len = w->instLen;
        /* Warriors declaring the same PIN share P-space (except cell 0). */
        warrior->have_pin = w->pSpaceIndex == PIN_APPEARED;
        warrior->pin = w->pSpaceIDNumber;
        in = warrior->code;
        
        for (i=0; i < w->instLen; ++i) {
            /* pmars */
            mem_struct* cell = w->instBank + i;
            FIELD_T opcode = ((FIELD_T) (cell->opcode & 0xf8)) >> 3;
            FIELD_T modifier = (cell->opcode & 0x07);

            /* exhaust */
            int op, m, ma, mb;
            int flags = 0;
            
            op = p2eOp[opcode];
            m = p2eModifier[modifier];
            
            ma = PM_INDIR_A(cell->A_mode) ? p2eAddr[INDIR_A_TO_SYM(cell->A_mode)] : p2eAddr[cell->A_mode];
            in->a = MODS(cell->A_value, (int)mars->coresize);
            mb = PM_INDIR_A(cell->B_mode) ? p2eAddr[INDIR_A_TO_SYM(cell->B_mode)] : p2eAddr[cell->B_mode];
            in->b = MODS(cell->B_value, (int)mars->coresize);            

            in->in = (flags << flPOS) | OP( op, m, ma, mb );
            ++in;
            
            /* build new instruction */
            /*
              sprintf(instrStr, "Instruction.new(\"%s\", \"%s\", \"%c\", %d, \"%c\", %d)",
              replaceOpname,
              modname[modifier],
              PM_INDIR_A(cell->A_mode) ? addr_sym[INDIR_A_TO_SYM(cell->A_mode)] : addr_sym[cell->A_mode],
              cell->A_value,
              PM_INDIR_A(cell->B_mode) ? addr_sym[INDIR_A_TO_SYM(cell->B_mode)] : addr_sym[cell->B_mode],
              cell->B_value);
              rb_ary_push(rInstructions, rb_eval_string(instrStr));
            */
        }   
    
    }
}


int main(int argc, char** argv) {
    u32_t i;
    warriorNames_t* currWarrior;
    warrior_struct** warriors;

    if (argc == 2 && strcmp(argv[1], "--version") == 0) {
        printf("exMARS %s — AI-assisted fork of exMARS 0.01\n", EXMARS_VERSION);
        return 0;
    }

    /* setup mars */
    mars_t* mars = init(argc, argv);
    if ( mars->nWarriors == 0 )
        usage();

    
    /* load warriors into pmars data structure */
    currWarrior = mars->warriorNames;
    warriors = (warrior_struct**)malloc(sizeof(warrior_struct*)*mars->nWarriors);
    i=0;
    while (currWarrior != NULL) 
    {
        warrior_struct* w = (warrior_struct*)MALLOC(sizeof(warrior_struct));
        warriors[i] = w;
        
        memset(w, 0, sizeof(warrior_struct));
        if (assemble_warrior(mars, currWarrior->warriorName, w)) {
            printf("can not load warrior '%s'\n", w->fileName);
        }
        currWarrior = currWarrior->next;
        ++i;
    }

    /* print warriors */
#if 0
    for (i=0; i<mars->nWarriors; ++i) 
    {
        warrior_struct* w = warriors[i];
        fprintf(STDOUT, "Program \"%s\" (length %d) by \"%s\"\n\n", w->name, w->instLen, w->authorName);
        disasm(mars, w->instBank, w->instLen, w->offset);    
        fprintf(STDOUT, "\n\n");        
    }
#endif
    
    /*  convert warriors */
    pmars2exhaust(mars, warriors, mars->nWarriors);
#if 0
    for (i=0; i<mars->nWarriors; ++i) 
    {
        discore(mars->warriors[i].code, 0, mars->warriors[i].len, mars->coresize);
    }
#endif
    /* fight! */
    check_sanity(mars);
    if (mars_match(mars) != MATCH_OK)
        panic(mars->errmsg);

    output_results(mars);
    sim_free_bufs(mars);
    
    FREE(warriors);
	return 0;
}

/* * =================================================================
 * NEW FUNCTION FOR IN-MEMORY PARSING
 * Add this to the end of pmars.c
 * =================================================================
 */
#include <string.h> // Make sure this is at the top of pmars.c

static int assemble_string(mars_t* mars, const char* redcode_string, warrior_struct* w)
{
    /* Most setup is copied directly from assemble_warrior */
    uChar   cont = TRUE, conLine = FALSE, i;
    uShrt   lines;                /* logical and physical lines */
    uShrt   spnt = 0;             /* index/pointer to sline and lline */

    /* release all allocated memory */
    mars->errorlevel = WARNING;
    mars->errorcode = SUCCESS;
    *(mars->errmsg) = '\0';
    mars->errnum = mars->warnum = 0;

    mars->pass = 0;

    mars->srctbl = NULL;
    mars->sline[0] = mars->sline[1] = NULL;
    mars->reftbl = NULL;
    mars->symtbl = NULL;
    mars->symnum = 0;

    lines = 0;
    mars->ierr = 0;

    if (mars->errkeep == NULL) {
        if ((mars->errkeep = (err_st *) MALLOC(sizeof(err_st) * ERRMAX)) == NULL)
            MEMORYERROR;
    }

    w->name = pstrdup(unknown);
    w->authorName = pstrdup(anonymous);
    w->date = pstrdup("");
    w->version = pstrdup("");
    w->pSpaceIndex = UNSHARED;
    w->instBank = NULL;
    w->instLen = 0;
    mars->dbgproceed = TRUE;
    mars->dbginfo = FALSE;
    mars->noassert = TRUE;

    addpredefs(mars);

    /* * ==================================================
     * This is the REPLACEMENT for the file-reading loop 
     * ==================================================
     */
    char* redcode_copy = strdup(redcode_string); /* Need a mutable copy for strtok_r */
    if (redcode_copy == NULL) MEMORYERROR;
    
    char* saveptr;
    char* line = strtok_r(redcode_copy, "\n\r", &saveptr); /* Split by newline or carriage return */
    char pstart = 0;
    lines = 0;
    mars->aline = NULL;

    while (line != NULL) {
        lines++;
        i = 0; // Reset index for get_token
        
        // Copy the line into the mars buffer for processing
        strncpy(mars->buf, line, MAXALLCHAR - 1);
        mars->buf[MAXALLCHAR - 1] = '\0'; // Ensure null termination
        
        // This logic is identical to the file loop
        switch (get_token(mars->buf, &i, mars->token)) {
        case COMMTOKEN:
            if ((globalswitch_warrior(mars, w, mars->buf, (uShrt) i, lines, spnt))) { /* REDCODE? */
                switch (pstart) {
                case 0:
                    disposeline(mars->sline[spnt]);
                    mars->sline[spnt] = mars->lline[spnt] = NULL;
                    pstart++;
                    break;
                case 1:
                    pstart++;
                    /* fallthru */
                case 2:
                    line = NULL; // Stop processing
                    break;
                }
            }
            break;
        case NONE:
            break; // Blank line
        default:
            nocmnt(mars->buf);                /* saving some space */
            // Using "from_string" as a placeholder for the source name
            addline(mars, mars->buf, addlinesrc(mars, "from_string", lines), spnt);
            break;
        }
        
        if (line != NULL) {
            line = strtok_r(NULL, "\n\r", &saveptr); // Get next line
        }
    }
    free(redcode_copy); // Free the mutable copy
    /* ==================================================
     * End of new logic
     * ==================================================
     */
    
    if (pstart)
        pstart--;

    mars->line = 0;
    expand(mars, spnt);

    if (mars->symtbl) {
        grp_st *tmp;
        *(mars->buf) = '\0';
        for (tmp = mars->symtbl; tmp; tmp = tmp->nextsym) {
            if (*(mars->buf))
                if (!concat(mars->buf, " "))
                    break;
            if (!concat(mars->buf, tmp->symn))
                break;
        }
        errprn(mars, DLBERR, (line_st *) NULL, mars->buf);
        disposegrp(mars->symtbl);
        mars->symtbl = NULL;
        mars->symnum = 0;
    }
    spnt = 1 - spnt;
    mars->pass++;

    if (mars->noassert)
        errprn(mars, NASERR, (line_st *) NULL, "");

    /* printf("Entering pass 2 (parsing and loading)\n"); */
    encode_warrior(mars, w, spnt);

    mars->dbginfo = FALSE;
    mars->dbgproceed = TRUE;
    /* release all allocated memory */
    cleanmem(mars);
    while (mars->srctbl) {
        src_st *tmp = mars->srctbl;
        mars->srctbl = mars->srctbl->nextsrc;
        FREE(tmp->src);
        FREE(tmp);
    }

    if (mars->errnum) {
        FREE(w->instBank);
        w->instLen = 0;
    }
    if (mars->errnum) {
        sprintf(mars->outs, errNumMsg, mars->errnum);
        textout(mars->outs);
    }
    if (mars->warnum) {
        sprintf(mars->outs, warNumMsg, mars->warnum);
        textout(mars->outs);
    }
    while (mars->ierr)
        if (mars->errkeep[--(mars->ierr)].num > 1) {
            sprintf(mars->outs, duplicateMsg, mars->errkeep[mars->ierr].loc, mars->errkeep[mars->ierr].num);
            textout(mars->outs);
        }
    if (mars->errnum + mars->warnum) {
        sprintf(mars->outs, "\n");
        textout(mars->outs);
    }

    if (mars->errnum)
        mars->errorcode = PARSEERR;
    else
        mars->errorcode = SUCCESS;
    reset_regs(mars);
    return (mars->errorcode);
}

/* After a parse_abort(): free what the parser held and report the code. The
 * warrior keeps its name/author/date/version strings, as after any failed
 * assembly; the caller frees them. mars->errmsg says what went wrong. */
static int parse_abort_cleanup(mars_t* mars, warrior_struct* w, int code)
{
    if (mars->parseFile) {
        fclose(mars->parseFile);
        mars->parseFile = NULL;
    }
    cleanmem(mars);
    while (mars->srctbl) {
        src_st *tmp = mars->srctbl;
        mars->srctbl = mars->srctbl->nextsrc;
        FREE(tmp->src);
        FREE(tmp);
    }
    FREE(w->instBank);
    w->instLen = 0;
    mars->ierr = 0;
    mars->errorcode = code;
    reset_regs(mars);
    return code;
}

/*
 * The public entry points. They return SUCCESS (0) or an error code:
 * PARSEERR for a warrior that does not assemble (also after too many errors),
 * MEMERR when memory ran out, SERIOUS for an internal error. They never exit().
 */
int assemble_warrior(mars_t* mars, char* fName, warrior_struct* w)
{
    jmp_buf here;
    jmp_buf *outer = mars->parseAbort;
    int code;

    mars->parseAbort = &here;
    mars->parseFile = NULL;
    if (setjmp(here) == 0)
        code = assemble_file(mars, fName, w);
    else
        code = parse_abort_cleanup(mars, w, mars->errorcode);
    mars->parseAbort = outer;
    return code;
}

int assemble_warrior_from_string(mars_t* mars, const char* redcode_string, warrior_struct* w)
{
    jmp_buf here;
    jmp_buf *outer = mars->parseAbort;
    int code;

    mars->parseAbort = &here;
    mars->parseFile = NULL;
    if (setjmp(here) == 0)
        code = assemble_string(mars, redcode_string, w);
    else
        code = parse_abort_cleanup(mars, w, mars->errorcode);
    mars->parseAbort = outer;
    return code;
}

